import React, { useState, useEffect, useCallback, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import toast from "react-hot-toast";
import axios from "axios";
import { useGameStore } from "../utils/store";

const API = process.env.REACT_APP_API_URL || "";
const MUNDOS_TOTAL = 10;

export default function AdminPage() {
  const store = useGameStore();
  const [tab, setTab] = useState("licencias");
  const [licencias, setLicencias] = useState([]);
  const [solicitudes, setSolicitudes] = useState([]);
  const [reportes, setReportes] = useState([]);
  const [loading, setLoading] = useState(false);
  const [busqueda, setBusqueda] = useState("");
  const [editando, setEditando] = useState(null);

  // Crear licencia
  const [newCodigo, setNewCodigo] = useState("");
  const [newTipo, setNewTipo] = useState("alumno");
  const [newNombre, setNewNombre] = useState("");
  const [newCorreo, setNewCorreo] = useState("");
  const [newCelular, setNewCelular] = useState("");
  const [newGrado, setNewGrado] = useState("");
  const [newMaestroLic, setNewMaestroLic] = useState("");
  const [autoGenerando, setAutoGenerando] = useState(false);

  // Cambiar contraseña admin
  const [pwActual, setPwActual] = useState("");
  const [pwNueva, setPwNueva] = useState("");
  const [pwConfirm, setPwConfirm] = useState("");
  const [pwLoading, setPwLoading] = useState(false);

  // Reporte seleccionado para imprimir
  const [reporteSeleccionado, setReporteSeleccionado] = useState(null);
  const printRef = useRef();

  const cargar = useCallback(async () => {
    setLoading(true);
    try {
      const [rLic, rSol, rRep] = await Promise.all([
        axios.get(`${API}/api/admin/licencias`),
        axios.get(`${API}/api/admin/solicitudes`).catch(() => ({ data: { solicitudes: [] } })),
        axios.get(`${API}/api/admin/reportes`).catch(() => ({ data: { reportes: [] } })),
      ]);
      setLicencias(rLic.data.licencias || []);
      setSolicitudes(rSol.data.solicitudes || []);
      setReportes(rRep.data.reportes || []);
    } catch { toast.error("Error al cargar datos del servidor"); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { cargar(); }, [cargar]);

  const autoGenerarCodigo = async () => {
    if (!newNombre.trim()) { toast.error("Escribe el nombre primero"); return; }
    setAutoGenerando(true);
    try {
      const { data } = await axios.post(`${API}/api/admin/generar-codigo`, {
        nombre: newNombre.trim(), tipo: newTipo,
      });
      setNewCodigo(data.codigo);
      toast.success("✅ Código generado automáticamente");
    } catch { toast.error("Error al generar código"); }
    finally { setAutoGenerando(false); }
  };

  const crear = async () => {
    if (!newCodigo.trim()) { toast.error("Escribe un código o usa el botón de generar"); return; }
    try {
      await axios.post(`${API}/api/admin/crear-licencia`, {
        codigo: newCodigo.trim(), tipo: newTipo,
        nombre: newNombre, correo: newCorreo, celular: newCelular,
        grado: newGrado, maestro_licencia: newMaestroLic,
      });
      toast.success("✅ Licencia creada");
      setNewCodigo(""); setNewNombre(""); setNewCorreo(""); setNewCelular("");
      setNewGrado(""); setNewMaestroLic(""); setNewTipo("alumno");
      cargar(); setTab("licencias");
    } catch (e) {
      toast.error(e.response?.data?.detail || "Error al crear licencia");
    }
  };

  const activar = async (codigo) => {
    try {
      const { data } = await axios.post(`${API}/api/admin/activar-licencia`, { codigo });
      toast.success(data.correo_enviado ? "✅ Activada — correo enviado" : "✅ Activada (sin correo configurado)");
      cargar();
    } catch { toast.error("Error al activar"); }
  };

  const desactivar = async (codigo) => {
    if (!window.confirm(`¿Desactivar la licencia ${codigo}?`)) return;
    try {
      await axios.post(`${API}/api/admin/desactivar-licencia`, { codigo });
      toast.success("Licencia desactivada");
      cargar();
    } catch { toast.error("Error al desactivar"); }
  };

  const eliminar = async (codigo) => {
    if (!window.confirm(`¿Eliminar permanentemente ${codigo}?`)) return;
    try {
      await axios.delete(`${API}/api/admin/eliminar-licencia/${codigo}`);
      toast.success("Licencia eliminada");
      cargar();
    } catch { toast.error("Error al eliminar"); }
  };

  const guardarEdicion = async () => {
    if (!editando) return;
    try {
      await axios.post(`${API}/api/admin/editar-licencia`, {
        licencia: editando.Licencia,
        nombre: editando.Nombre || "",
        correo: editando.Correo || "",
        celular: editando.Celular || "",
        monedas: editando.Monedas || 0,
        nivel_max: editando.Nivel_Max || 1,
        grado: editando.Grado || "",
        maestro_licencia: editando.Maestro_Licencia || "",
      });
      toast.success("✅ Datos actualizados");
      setEditando(null);
      cargar();
    } catch { toast.error("Error al guardar"); }
  };

  const cambiarPassword = async () => {
    if (!pwActual.trim()) { toast.error("Escribe tu licencia actual"); return; }
    if (!pwNueva.trim() || pwNueva.length < 6) { toast.error("La nueva licencia debe tener al menos 6 caracteres"); return; }
    if (pwNueva !== pwConfirm) { toast.error("Las licencias nuevas no coinciden"); return; }
    setPwLoading(true);
    try {
      await axios.post(`${API}/api/admin/cambiar-licencia`, {
        licencia_actual: pwActual.trim(), licencia_nueva: pwNueva.trim(),
      });
      toast.success("✅ ¡Licencia de admin cambiada! Cerrando sesión...");
      setPwActual(""); setPwNueva(""); setPwConfirm("");
      setTimeout(() => store.cerrarSesion(), 2000);
    } catch (e) {
      toast.error(`❌ ${e.response?.data?.detail || "Error al cambiar"}`);
    } finally { setPwLoading(false); }
  };

  const imprimirReporte = (rep) => {
    setReporteSeleccionado(rep);
    setTimeout(() => {
      const contenido = printRef.current?.innerHTML;
      if (!contenido) return;
      const w = window.open("", "_blank");
      w.document.write(`<!DOCTYPE html><html><head><title>Reporte — ${rep.Nombre}</title>
<style>
  body{font-family:Arial,sans-serif;padding:30px;background:#fff;color:#000;}
  h1{color:#1a1f4e;font-size:22px;margin-bottom:4px;}
  h2{color:#3a3f7e;font-size:16px;margin-top:20px;border-bottom:2px solid #1a1f4e;padding-bottom:4px;}
  .grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin:12px 0;}
  .box{background:#f5f7ff;border:1px solid #dde;border-radius:8px;padding:12px;}
  .label{font-size:10px;text-transform:uppercase;color:#777;margin-bottom:3px;}
  .val{font-size:18px;font-weight:700;color:#1a1f4e;}
  .bar-bg{background:#eee;border-radius:4px;height:18px;margin:4px 0;}
  .bar{background:linear-gradient(90deg,#667eea,#764ba2);border-radius:4px;height:18px;}
  .tabla-row{display:flex;justify-content:space-between;padding:4px 0;border-bottom:1px solid #eee;font-size:13px;}
  .footer{margin-top:30px;font-size:11px;color:#aaa;text-align:center;}
</style></head><body>
${contenido}
<div class="footer">Aventura de Tablas Pro — Reporte generado el ${new Date().toLocaleDateString("es-MX", {year:"numeric",month:"long",day:"numeric"})}</div>
</body></html>`);
      w.document.close();
      w.print();
    }, 200);
  };

  const licenciasFiltradas = licencias.filter(l =>
    !busqueda ||
    String(l.Licencia || "").toLowerCase().includes(busqueda.toLowerCase()) ||
    String(l.Nombre   || "").toLowerCase().includes(busqueda.toLowerCase()) ||
    String(l.Correo   || "").toLowerCase().includes(busqueda.toLowerCase()) ||
    String(l.Tipo     || "").toLowerCase().includes(busqueda.toLowerCase())
  );

  const maestros = licencias.filter(l => l.Tipo === "maestro");
  const alumnos  = licencias.filter(l => l.Tipo === "alumno");
  const pendientes = solicitudes.filter(s => s.Estado === "Pendiente").length;
  const activas    = licencias.filter(l => l.Activa === "SI").length;

  const TABS = [
    { id:"licencias",   label:"🔑 Licencias" },
    { id:"maestros",    label:`🎓 Maestros${maestros.length ? ` (${maestros.length})` : ""}` },
    { id:"reportes",    label:`📊 Reportes` },
    { id:"crear",       label:"➕ Nueva" },
    { id:"solicitudes", label:`📨 Solicitudes${pendientes ? ` (${pendientes})` : ""}` },
    { id:"config",      label:"⚙️ Config" },
  ];

  return (
    <div className="page" style={{ background:"radial-gradient(ellipse at top,#0a001f 0%,#030010 70%)", minHeight:"100vh", paddingBottom:40 }}>

      {/* HEADER */}
      <div className="hud" style={{ background:"rgba(0,0,0,0.9)", borderBottom:"1px solid rgba(255,214,0,0.3)" }}>
        <div style={{ fontFamily:"Orbitron,monospace", fontSize:16, fontWeight:700, color:"#FFD700" }}>
          👑 ADMIN — {store.nombre}
        </div>
        <div style={{ marginLeft:"auto", display:"flex", gap:8 }}>
          <button onClick={() => useGameStore.setState({ pagina:"seleccion_avatar" })} className="btn btn-neon btn-sm">🎮 Jugar</button>
          <button onClick={() => store.cerrarSesion()} className="btn btn-danger btn-sm">🚪 Salir</button>
        </div>
      </div>

      <div style={{ maxWidth:980, margin:"0 auto", padding:"16px" }}>

        {/* Stats globales */}
        <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(130px,1fr))", gap:12, marginBottom:24 }}>
          {[
            { label:"Total",       value:licencias.length,            color:"#00f5ff", icon:"🔑" },
            { label:"Activas",     value:activas,                     color:"#39ff14", icon:"✅" },
            { label:"Maestros",    value:maestros.length,             color:"#a29bfe", icon:"🎓" },
            { label:"Alumnos",     value:alumnos.length,              color:"#00cec9", icon:"🧒" },
            { label:"Solicitudes", value:pendientes,                  color:"#FFD700", icon:"📨" },
          ].map(s => (
            <div key={s.label} style={{ background:"rgba(255,255,255,0.04)", border:`1px solid ${s.color}33`, borderRadius:16, padding:"14px 12px", textAlign:"center" }}>
              <div style={{ fontSize:22 }}>{s.icon}</div>
              <div style={{ fontFamily:"Orbitron,monospace", fontSize:24, fontWeight:700, color:s.color }}>{s.value}</div>
              <div style={{ fontFamily:"Nunito,sans-serif", fontSize:11, color:"rgba(255,255,255,0.4)", marginTop:2 }}>{s.label}</div>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div style={{ display:"flex", gap:4, marginBottom:20, flexWrap:"wrap" }}>
          {TABS.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)} style={{
              flex:1, minWidth:70, padding:"10px 6px",
              background: tab===t.id ? "linear-gradient(135deg,#667eea,#764ba2)" : "rgba(255,255,255,0.05)",
              border:`1px solid ${tab===t.id ? "transparent" : "rgba(255,255,255,0.1)"}`,
              borderRadius:12, color:tab===t.id ? "#fff" : "rgba(255,255,255,0.4)",
              fontFamily:"Orbitron,monospace", fontSize:10, cursor:"pointer", transition:"all 0.2s"
            }}>{t.label}</button>
          ))}
        </div>

        {loading && (
          <div style={{textAlign:"center",padding:40}}>
            <motion.div animate={{rotate:360}} transition={{duration:1,repeat:Infinity,ease:"linear"}} style={{fontSize:40,display:"inline-block"}}>⚙️</motion.div>
            <p style={{color:"rgba(255,255,255,0.4)",fontFamily:"Nunito,sans-serif",marginTop:12}}>Cargando datos...</p>
          </div>
        )}

        {/* ─── TAB LICENCIAS ─────────────────────────────────── */}
        {!loading && tab === "licencias" && (
          <div>
            <input className="input" placeholder="🔍 Buscar por código, nombre, correo, tipo..."
              value={busqueda} onChange={e => setBusqueda(e.target.value)} style={{ marginBottom:16, fontSize:15 }} />

            {licenciasFiltradas.length === 0 && (
              <div style={{textAlign:"center",padding:40,color:"rgba(255,255,255,0.3)",fontFamily:"Nunito,sans-serif"}}>
                {busqueda ? "Sin resultados" : "No hay licencias. Crea la primera."}
              </div>
            )}

            <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
              {licenciasFiltradas.map((lic, i) => (
                <motion.div key={lic.Licencia || i} initial={{opacity:0,x:-20}} animate={{opacity:1,x:0}} transition={{delay:i*0.02}}
                  style={{ background:"rgba(255,255,255,0.04)", border:`1px solid ${lic.Activa==="SI"?"rgba(57,255,20,0.2)":"rgba(255,0,110,0.2)"}`, borderRadius:16, padding:"14px 18px" }}>

                  {editando?.Licencia !== lic.Licencia ? (
                    <div style={{ display:"grid", gridTemplateColumns:"1fr auto", gap:12, alignItems:"start" }}>
                      <div>
                        <div style={{ display:"flex", alignItems:"center", gap:8, flexWrap:"wrap", marginBottom:6 }}>
                          <span style={{ fontFamily:"Orbitron,monospace", fontSize:14, color:"#fff" }}>{lic.Licencia}</span>
                          <span style={{ padding:"2px 8px", borderRadius:20, fontSize:10,
                            background: lic.Activa==="SI" ? "rgba(57,255,20,0.15)" : "rgba(255,0,110,0.15)",
                            color: lic.Activa==="SI" ? "#39ff14" : "#ff006e" }}>
                            {lic.Activa==="SI" ? "● ACTIVA" : "● INACTIVA"}
                          </span>
                          <span style={{ padding:"2px 8px", borderRadius:20, fontSize:10,
                            background: lic.Tipo==="maestro" ? "rgba(162,155,254,0.15)" : lic.Tipo==="admin" ? "rgba(255,214,0,0.15)" : "rgba(0,200,200,0.1)",
                            color: lic.Tipo==="maestro" ? "#a29bfe" : lic.Tipo==="admin" ? "#FFD700" : "#00cec9" }}>
                            {lic.Tipo==="maestro"?"🎓 Maestro":lic.Tipo==="admin"?"👑 Admin":"🧒 Alumno"}
                          </span>
                          {lic.Grado && <span style={{ fontSize:11, color:"rgba(255,255,255,0.4)" }}>Grado: {lic.Grado}</span>}
                          {lic.Fecha_Vence && <span style={{ fontSize:10, color:"rgba(255,214,0,0.5)" }}>Vence: {lic.Fecha_Vence}</span>}
                        </div>
                        <div style={{ fontFamily:"Nunito,sans-serif", fontSize:12, color:"rgba(255,255,255,0.45)", display:"flex", gap:12, flexWrap:"wrap" }}>
                          <span>👤 {lic.Nombre || "Sin nombre"}</span>
                          <span>📧 {lic.Correo || "Sin correo"}</span>
                          {lic.Celular && <span>📱 {lic.Celular}</span>}
                          <span>🪙 {lic.Monedas || 0}</span>
                          <span>🌍 Nivel: {lic.Nivel_Max || 1}</span>
                          {lic.Mundos_Completados > 0 && <span>🏆 Mundos: {lic.Mundos_Completados}</span>}
                          {lic.Tiempo_Total_Min > 0 && <span>⏱ {lic.Tiempo_Total_Min} min</span>}
                        </div>
                      </div>
                      <div style={{ display:"flex", gap:6, flexWrap:"wrap", justifyContent:"flex-end" }}>
                        <button onClick={() => setEditando({ ...lic })}
                          style={{ background:"rgba(0,245,255,0.1)", border:"1px solid rgba(0,245,255,0.3)", color:"#00f5ff", borderRadius:8, cursor:"pointer", padding:"5px 10px", fontSize:11, fontFamily:"Nunito,sans-serif" }}>
                          ✏️
                        </button>
                        {lic.Activa !== "SI" ? (
                          <button onClick={() => activar(lic.Licencia)}
                            style={{ background:"rgba(57,255,20,0.15)", border:"1px solid rgba(57,255,20,0.3)", color:"#39ff14", borderRadius:8, cursor:"pointer", padding:"5px 10px", fontSize:11 }}>
                            ✅ Activar
                          </button>
                        ) : lic.Tipo !== "admin" && (
                          <button onClick={() => desactivar(lic.Licencia)}
                            style={{ background:"rgba(255,140,0,0.15)", border:"1px solid rgba(255,140,0,0.3)", color:"#ff8c00", borderRadius:8, cursor:"pointer", padding:"5px 10px", fontSize:11 }}>
                            🚫
                          </button>
                        )}
                        {lic.Tipo !== "admin" && (
                          <button onClick={() => eliminar(lic.Licencia)}
                            style={{ background:"rgba(255,0,110,0.1)", border:"1px solid rgba(255,0,110,0.2)", color:"#ff006e", borderRadius:8, cursor:"pointer", padding:"5px 8px", fontSize:11 }}>
                            🗑️
                          </button>
                        )}
                      </div>
                    </div>
                  ) : (
                    <div>
                      <div style={{ fontFamily:"Orbitron,monospace", fontSize:12, color:"#00f5ff", marginBottom:12 }}>✏️ Editando: {lic.Licencia}</div>
                      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10, marginBottom:12 }}>
                        {[
                          { field:"Nombre", label:"Nombre", type:"text" },
                          { field:"Correo", label:"Correo", type:"email" },
                          { field:"Celular", label:"Celular", type:"tel" },
                          { field:"Grado", label:"Grado escolar", type:"text" },
                          { field:"Maestro_Licencia", label:"Código del maestro", type:"text" },
                          { field:"Monedas", label:"Monedas", type:"number" },
                          { field:"Nivel_Max", label:"Nivel Max (1-11)", type:"number" },
                        ].map(({ field, label, type }) => (
                          <div key={field}>
                            <label style={{ fontFamily:"Nunito,sans-serif", fontSize:11, color:"rgba(255,255,255,0.4)", display:"block", marginBottom:3 }}>{label}</label>
                            <input className="input" style={{ fontSize:13 }} type={type}
                              value={editando[field] || ""}
                              onChange={e => setEditando(p => ({ ...p, [field]: type==="number" ? parseInt(e.target.value)||0 : e.target.value }))}
                            />
                          </div>
                        ))}
                      </div>
                      <div style={{ display:"flex", gap:8 }}>
                        <button onClick={guardarEdicion} className="btn btn-primary btn-sm" style={{ flex:1 }}>💾 Guardar</button>
                        <button onClick={() => setEditando(null)}
                          style={{ flex:1, background:"rgba(255,255,255,0.08)", border:"1px solid rgba(255,255,255,0.15)", borderRadius:10, color:"rgba(255,255,255,0.6)", cursor:"pointer", fontFamily:"Nunito,sans-serif", fontSize:13, padding:"8px" }}>
                          Cancelar
                        </button>
                      </div>
                    </div>
                  )}
                </motion.div>
              ))}
            </div>
          </div>
        )}

        {/* ─── TAB MAESTROS ───────────────────────────────────── */}
        {!loading && tab === "maestros" && (
          <div>
            {maestros.length === 0 && (
              <div style={{ textAlign:"center", padding:40, color:"rgba(255,255,255,0.3)", fontFamily:"Nunito,sans-serif" }}>
                No hay maestros registrados. Crea una licencia de tipo "Maestro".
              </div>
            )}
            <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
              {maestros.map((mae, i) => {
                const susAlumnos = alumnos.filter(a => a.Maestro_Licencia === mae.Licencia);
                return (
                  <motion.div key={mae.Licencia} initial={{opacity:0,y:10}} animate={{opacity:1,y:0}} transition={{delay:i*0.05}}
                    style={{ background:"rgba(162,155,254,0.06)", border:"1px solid rgba(162,155,254,0.25)", borderRadius:18, padding:"18px 20px" }}>
                    <div style={{ display:"flex", alignItems:"center", gap:12, marginBottom:12, flexWrap:"wrap" }}>
                      <div style={{ fontSize:36 }}>🎓</div>
                      <div>
                        <div style={{ fontFamily:"Orbitron,monospace", fontSize:15, color:"#a29bfe", fontWeight:700 }}>{mae.Nombre || "Sin nombre"}</div>
                        <div style={{ fontFamily:"Nunito,sans-serif", fontSize:12, color:"rgba(255,255,255,0.45)" }}>
                          {mae.Licencia} • {mae.Correo || "Sin correo"} {mae.Celular && `• ${mae.Celular}`}
                        </div>
                        {mae.Grado && <div style={{ fontFamily:"Nunito,sans-serif", fontSize:12, color:"#a29bfe" }}>Grado: {mae.Grado}</div>}
                      </div>
                      <div style={{ marginLeft:"auto", textAlign:"right" }}>
                        <div style={{ fontFamily:"Orbitron,monospace", fontSize:22, color:"#00cec9", fontWeight:700 }}>{susAlumnos.length}</div>
                        <div style={{ fontFamily:"Nunito,sans-serif", fontSize:10, color:"rgba(255,255,255,0.35)" }}>alumnos</div>
                      </div>
                    </div>

                    {susAlumnos.length > 0 && (
                      <div style={{ borderTop:"1px solid rgba(162,155,254,0.15)", paddingTop:12 }}>
                        <div style={{ fontFamily:"Nunito,sans-serif", fontSize:12, color:"rgba(255,255,255,0.4)", marginBottom:8 }}>Alumnos de este maestro:</div>
                        <div style={{ display:"flex", flexDirection:"column", gap:6 }}>
                          {susAlumnos.map(alu => {
                            const pct = Math.round(((alu.Mundos_Completados || 0) / MUNDOS_TOTAL) * 100);
                            return (
                              <div key={alu.Licencia} style={{ background:"rgba(0,0,0,0.3)", borderRadius:10, padding:"10px 14px", display:"flex", alignItems:"center", gap:12, flexWrap:"wrap" }}>
                                <div style={{ flex:1 }}>
                                  <div style={{ fontFamily:"Nunito,sans-serif", fontSize:13, color:"#fff", fontWeight:700 }}>{alu.Nombre || "Sin nombre"}</div>
                                  <div style={{ fontFamily:"Nunito,sans-serif", fontSize:11, color:"rgba(255,255,255,0.35)" }}>
                                    {alu.Grado && `${alu.Grado} • `}{alu.Licencia}
                                  </div>
                                </div>
                                <div style={{ minWidth:120 }}>
                                  <div style={{ display:"flex", justifyContent:"space-between", fontFamily:"Nunito,sans-serif", fontSize:11, color:"rgba(255,255,255,0.5)", marginBottom:3 }}>
                                    <span>Progreso</span><span>{pct}%</span>
                                  </div>
                                  <div style={{ background:"rgba(255,255,255,0.1)", borderRadius:4, height:6 }}>
                                    <div style={{ width:`${pct}%`, background:"linear-gradient(90deg,#667eea,#a29bfe)", borderRadius:4, height:6 }}/>
                                  </div>
                                </div>
                                <div style={{ textAlign:"center", minWidth:60 }}>
                                  <div style={{ fontFamily:"Nunito,sans-serif", fontSize:11, color:"rgba(255,255,255,0.35)" }}>Tiempo</div>
                                  <div style={{ fontFamily:"Orbitron,monospace", fontSize:12, color:"#00f5ff" }}>{alu.Tiempo_Total_Min || 0} min</div>
                                </div>
                                <span style={{ padding:"3px 8px", borderRadius:12, fontSize:10, background: alu.Activa==="SI"?"rgba(57,255,20,0.15)":"rgba(255,0,110,0.15)", color:alu.Activa==="SI"?"#39ff14":"#ff006e" }}>
                                  {alu.Activa==="SI"?"Activo":"Inactivo"}
                                </span>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {susAlumnos.length === 0 && (
                      <div style={{ fontFamily:"Nunito,sans-serif", fontSize:12, color:"rgba(255,255,255,0.25)", textAlign:"center", padding:"8px 0" }}>
                        Este maestro aún no tiene alumnos asignados
                      </div>
                    )}

                    <div style={{ marginTop:12 }}>
                      <button onClick={() => { setNewMaestroLic(mae.Licencia); setNewTipo("alumno"); setTab("crear"); }}
                        style={{ background:"rgba(162,155,254,0.15)", border:"1px solid rgba(162,155,254,0.3)", color:"#a29bfe", borderRadius:10, padding:"7px 16px", cursor:"pointer", fontFamily:"Nunito,sans-serif", fontSize:12 }}>
                        ➕ Agregar alumno a {mae.Nombre?.split(" ")[0] || "este maestro"}
                      </button>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>
        )}

        {/* ─── TAB REPORTES ───────────────────────────────────── */}
        {!loading && tab === "reportes" && (
          <div>
            {/* Reporte oculto para impresión */}
            <div ref={printRef} style={{ display:"none" }}>
              {reporteSeleccionado && <ContenidoImpresion rep={reporteSeleccionado} />}
            </div>

            {reportes.length === 0 && alumnos.length === 0 && (
              <div style={{ textAlign:"center", padding:40, color:"rgba(255,255,255,0.3)", fontFamily:"Nunito,sans-serif" }}>
                No hay alumnos registrados aún.
              </div>
            )}

            {/* Filtro por maestro */}
            <div style={{ display:"flex", gap:8, marginBottom:16, flexWrap:"wrap" }}>
              <select className="input" style={{ flex:1, maxWidth:280, cursor:"pointer" }}
                value={busqueda} onChange={e => setBusqueda(e.target.value)}>
                <option value="">— Todos los alumnos —</option>
                {maestros.map(m => <option key={m.Licencia} value={m.Licencia}>🎓 {m.Nombre}</option>)}
              </select>
              <button onClick={cargar} className="btn btn-neon btn-sm">🔄 Actualizar</button>
            </div>

            <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
              {(reportes.length > 0 ? reportes : alumnos).filter(a =>
                !busqueda || a.Maestro_Licencia === busqueda
              ).map((rep, i) => {
                const mundos = rep.Mundos_Completados || rep.Nivel_Max - 1 || 0;
                const pct = Math.round((mundos / MUNDOS_TOTAL) * 100);
                let fallos = {};
                try { fallos = JSON.parse(rep.Fallos_Tablas || "{}"); } catch {}
                const tablasProblema = Object.entries(fallos).filter(([,v]) => v >= 3).sort((a,b) => b[1]-a[1]);
                const tiempoMin = rep.Tiempo_Total_Min || 0;
                const horas = Math.floor(tiempoMin / 60);
                const mins = tiempoMin % 60;

                return (
                  <motion.div key={rep.Licencia || i} initial={{opacity:0,y:10}} animate={{opacity:1,y:0}} transition={{delay:i*0.04}}
                    style={{ background:"rgba(255,255,255,0.04)", border:"1px solid rgba(0,245,255,0.15)", borderRadius:18, padding:"16px 20px" }}>
                    <div style={{ display:"flex", alignItems:"flex-start", justifyContent:"space-between", gap:12, flexWrap:"wrap" }}>
                      <div style={{ flex:1 }}>
                        <div style={{ fontFamily:"Orbitron,monospace", fontSize:14, color:"#fff", marginBottom:4 }}>{rep.Nombre || "Sin nombre"}</div>
                        <div style={{ fontFamily:"Nunito,sans-serif", fontSize:12, color:"rgba(255,255,255,0.4)", marginBottom:10 }}>
                          {rep.Grado && `${rep.Grado} • `}{rep.Correo || rep.Licencia}
                          {rep.Maestro_Nombre && ` • 🎓 ${rep.Maestro_Nombre}`}
                        </div>

                        {/* Progreso */}
                        <div style={{ marginBottom:10 }}>
                          <div style={{ display:"flex", justifyContent:"space-between", fontFamily:"Nunito,sans-serif", fontSize:12, color:"rgba(255,255,255,0.5)", marginBottom:4 }}>
                            <span>Progreso: {mundos}/{MUNDOS_TOTAL} mundos</span>
                            <span style={{ color: pct>=80?"#39ff14":pct>=50?"#FFD700":"#ff006e", fontWeight:700 }}>{pct}%</span>
                          </div>
                          <div style={{ background:"rgba(255,255,255,0.08)", borderRadius:6, height:10 }}>
                            <div style={{ width:`${pct}%`, background:`linear-gradient(90deg,${pct>=80?"#39ff14,#00b894":pct>=50?"#FFD700,#e17055":"#ff006e,#fd79a8"})`, borderRadius:6, height:10, transition:"width 1s" }}/>
                          </div>
                        </div>

                        {/* Stats rápidas */}
                        <div style={{ display:"flex", gap:16, flexWrap:"wrap" }}>
                          <div style={{ fontFamily:"Nunito,sans-serif", fontSize:12, color:"rgba(255,255,255,0.4)" }}>
                            ⏱ <strong style={{ color:"#00f5ff" }}>{horas>0?`${horas}h `:""}${mins} min</strong> conectado
                          </div>
                          <div style={{ fontFamily:"Nunito,sans-serif", fontSize:12, color:"rgba(255,255,255,0.4)" }}>
                            🪙 <strong style={{ color:"#FFD700" }}>{rep.Monedas || 0}</strong> monedas
                          </div>
                          {tablasProblema.length > 0 && (
                            <div style={{ fontFamily:"Nunito,sans-serif", fontSize:12, color:"rgba(255,100,100,0.7)" }}>
                              ⚠️ Tablas difíciles: {tablasProblema.map(([t,v]) => `${t}(${v} fallos)`).join(", ")}
                            </div>
                          )}
                        </div>
                      </div>

                      <button onClick={() => imprimirReporte({ ...rep, mundos, pct, fallos, tablasProblema, tiempoMin, horas, mins })}
                        style={{ background:"rgba(255,214,0,0.12)", border:"2px solid rgba(255,214,0,0.35)", color:"#FFD700", borderRadius:12, padding:"10px 18px", cursor:"pointer", fontFamily:"Orbitron,monospace", fontSize:11, fontWeight:700, whiteSpace:"nowrap" }}>
                        🖨️ Imprimir
                      </button>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>
        )}

        {/* ─── TAB CREAR ──────────────────────────────────────── */}
        {!loading && tab === "crear" && (
          <motion.div initial={{opacity:0,y:20}} animate={{opacity:1,y:0}}
            className="card" style={{ background:"rgba(5,8,30,0.95)", maxWidth:520, margin:"0 auto" }}>
            <h3 style={{ fontFamily:"Orbitron,monospace", color:"#00f5ff", marginBottom:20, fontSize:16 }}>➕ Nueva Licencia</h3>
            <div style={{ display:"flex", flexDirection:"column", gap:12 }}>

              <div>
                <label style={{ fontFamily:"Nunito,sans-serif", fontSize:13, color:"rgba(255,255,255,0.5)", display:"block", marginBottom:6 }}>Tipo de usuario</label>
                <select value={newTipo} onChange={e => setNewTipo(e.target.value)} className="input" style={{ cursor:"pointer" }}>
                  <option value="alumno">🧒 Alumno</option>
                  <option value="maestro">🎓 Maestro</option>
                  <option value="admin">👑 Admin adicional</option>
                </select>
              </div>

              {[
                { val:newNombre,  set:setNewNombre,  label:"Nombre completo *", ph:"Nombre del alumno/maestro", type:"text" },
                { val:newCorreo,  set:setNewCorreo,  label:"Correo electrónico", ph:"correo@ejemplo.com", type:"email" },
                { val:newCelular, set:setNewCelular, label:"Celular", ph:"10 dígitos", type:"tel" },
              ].map(({ val, set, label, ph, type }) => (
                <div key={label}>
                  <label style={{ fontFamily:"Nunito,sans-serif", fontSize:13, color:"rgba(255,255,255,0.5)", display:"block", marginBottom:6 }}>{label}</label>
                  <input className="input" placeholder={ph} value={val} onChange={e => set(e.target.value)} type={type} />
                </div>
              ))}

              {newTipo === "alumno" && (
                <>
                  <div>
                    <label style={{ fontFamily:"Nunito,sans-serif", fontSize:13, color:"rgba(255,255,255,0.5)", display:"block", marginBottom:6 }}>Grado escolar</label>
                    <select value={newGrado} onChange={e => setNewGrado(e.target.value)} className="input" style={{ cursor:"pointer" }}>
                      <option value="">— Seleccionar grado —</option>
                      {["1° Primaria","2° Primaria","3° Primaria","4° Primaria","5° Primaria","6° Primaria","1° Secundaria","2° Secundaria","3° Secundaria"].map(g =>
                        <option key={g} value={g}>{g}</option>
                      )}
                    </select>
                  </div>
                  <div>
                    <label style={{ fontFamily:"Nunito,sans-serif", fontSize:13, color:"rgba(255,255,255,0.5)", display:"block", marginBottom:6 }}>Maestro asignado</label>
                    <select value={newMaestroLic} onChange={e => setNewMaestroLic(e.target.value)} className="input" style={{ cursor:"pointer" }}>
                      <option value="">— Sin maestro asignado —</option>
                      {maestros.map(m => <option key={m.Licencia} value={m.Licencia}>🎓 {m.Nombre} ({m.Licencia})</option>)}
                    </select>
                  </div>
                </>
              )}

              {newTipo === "maestro" && (
                <div>
                  <label style={{ fontFamily:"Nunito,sans-serif", fontSize:13, color:"rgba(255,255,255,0.5)", display:"block", marginBottom:6 }}>Grado / salón que imparte</label>
                  <input className="input" placeholder="ej: 2° A Primaria" value={newGrado} onChange={e => setNewGrado(e.target.value)} />
                </div>
              )}

              {/* Código */}
              <div>
                <label style={{ fontFamily:"Nunito,sans-serif", fontSize:13, color:"rgba(255,255,255,0.5)", display:"block", marginBottom:6 }}>Código de licencia *</label>
                <div style={{ display:"flex", gap:8 }}>
                  <input className="input" style={{ flex:1, fontFamily:"Orbitron,monospace", letterSpacing:2, fontSize:13 }}
                    placeholder="ej: ALU-MARIA-2025" value={newCodigo} onChange={e => setNewCodigo(e.target.value)} />
                  <button onClick={autoGenerarCodigo} disabled={autoGenerando}
                    style={{ background:"rgba(0,245,255,0.15)", border:"1px solid rgba(0,245,255,0.35)", color:"#00f5ff", borderRadius:10, padding:"0 14px", cursor:"pointer", fontFamily:"Nunito,sans-serif", fontSize:12, whiteSpace:"nowrap" }}>
                    {autoGenerando ? "..." : "⚡ Auto"}
                  </button>
                </div>
              </div>

              <div className="tip-box" style={{ fontSize:12 }}>
                💡 Al <strong>activar</strong> la licencia se envía el correo automáticamente. Si es alumno de un maestro, el correo incluirá los datos del maestro.
              </div>
              <button className="btn btn-primary btn-full" style={{ padding:16, fontSize:15, marginTop:4 }} onClick={crear}>
                ➕ CREAR LICENCIA
              </button>
            </div>
          </motion.div>
        )}

        {/* ─── TAB SOLICITUDES ────────────────────────────────── */}
        {!loading && tab === "solicitudes" && (
          <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
            {solicitudes.length === 0 && (
              <div style={{ textAlign:"center", padding:40, color:"rgba(255,255,255,0.3)", fontFamily:"Nunito,sans-serif" }}>
                No hay solicitudes aún.
              </div>
            )}
            {solicitudes.map((sol, i) => (
              <motion.div key={sol.id || i} initial={{opacity:0,x:-20}} animate={{opacity:1,x:0}} transition={{delay:i*0.04}}
                style={{ background:"rgba(255,255,255,0.04)", border:`1px solid ${sol.Estado==="Pendiente"?"rgba(255,214,0,0.2)":"rgba(57,255,20,0.2)"}`, borderRadius:16, padding:"18px 20px" }}>
                <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", gap:12, flexWrap:"wrap" }}>
                  <div style={{ flex:1 }}>
                    <div style={{ fontFamily:"Orbitron,monospace", fontSize:14, color:"#fff", marginBottom:4 }}>
                      {sol.Nombre} {sol.Tipo==="maestro" && <span style={{ color:"#a29bfe", fontSize:11 }}>🎓 Maestro</span>}
                    </div>
                    <div style={{ fontFamily:"Nunito,sans-serif", fontSize:12, color:"rgba(255,255,255,0.45)", display:"flex", gap:12, flexWrap:"wrap" }}>
                      <span>📧 {sol.Correo}</span>
                      <span>📱 {sol.Celular}</span>
                      <span>🏫 {sol.Escuela}</span>
                      {sol.Grado && <span>📚 {sol.Grado}</span>}
                      {sol.Num_Alumnos && <span>👥 {sol.Num_Alumnos} alumnos</span>}
                    </div>
                    <div style={{ fontFamily:"Nunito,sans-serif", fontSize:11, color:"rgba(255,255,255,0.25)", marginTop:4 }}>{sol.Fecha}</div>
                  </div>
                  <span style={{ padding:"4px 12px", borderRadius:20, fontSize:10,
                    background: sol.Estado==="Pendiente" ? "rgba(255,140,0,0.2)" : "rgba(57,255,20,0.15)",
                    color: sol.Estado==="Pendiente" ? "#ff8c00" : "#39ff14" }}>
                    {sol.Estado}
                  </span>
                </div>
                {sol.Estado === "Pendiente" && (
                  <div style={{ marginTop:12, padding:"10px 14px", background:"rgba(0,245,255,0.05)", borderRadius:12 }}>
                    <button onClick={() => { setNewNombre(sol.Nombre); setNewCorreo(sol.Correo); setNewCelular(sol.Celular); setNewTipo(sol.Tipo||"alumno"); setNewGrado(sol.Grado||""); setTab("crear"); }}
                      className="btn btn-neon btn-sm">
                      ➕ Crear licencia para {sol.Nombre.split(" ")[0]}
                    </button>
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        )}

        {/* ─── TAB CONFIG ─────────────────────────────────────── */}
        {!loading && tab === "config" && (
          <motion.div initial={{opacity:0,y:20}} animate={{opacity:1,y:0}}
            className="card" style={{ background:"rgba(5,8,30,0.95)", maxWidth:500, margin:"0 auto" }}>

            <h3 style={{ fontFamily:"Orbitron,monospace", color:"#FFD700", marginBottom:8, fontSize:15 }}>⚙️ Cambiar Código de Admin</h3>
            <p style={{ fontFamily:"Nunito,sans-serif", color:"rgba(255,255,255,0.4)", fontSize:13, marginBottom:18 }}>
              Al cambiarlo, el sistema cerrará tu sesión automáticamente.
            </p>
            <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
              {[
                { val:pwActual,  set:setPwActual,  label:"🔑 Código actual",        ph:"Tu código actual" },
                { val:pwNueva,   set:setPwNueva,   label:"🔒 Nuevo código",         ph:"Mínimo 6 caracteres" },
                { val:pwConfirm, set:setPwConfirm, label:"🔒 Confirmar nuevo código", ph:"Repite el nuevo código" },
              ].map(({ val, set, label, ph }) => (
                <div key={label}>
                  <label style={{ fontFamily:"Nunito,sans-serif", fontSize:12, color:"rgba(255,255,255,0.45)", display:"block", marginBottom:5 }}>{label}</label>
                  <input className="input" placeholder={ph} value={val} onChange={e => set(e.target.value)} type="password" />
                </div>
              ))}
              {pwNueva && pwConfirm && pwNueva !== pwConfirm && (
                <div style={{ background:"rgba(255,0,110,0.1)", border:"1px solid rgba(255,0,110,0.3)", borderRadius:10, padding:"8px 14px", fontFamily:"Nunito,sans-serif", fontSize:12, color:"#ff006e" }}>
                  ⚠️ Los códigos no coinciden
                </div>
              )}
              <button className="btn btn-primary btn-full" style={{ padding:14 }} onClick={cambiarPassword} disabled={pwLoading}>
                {pwLoading ? "Cambiando..." : "🔒 CAMBIAR CÓDIGO DE ADMIN"}
              </button>
            </div>

            <div style={{ borderTop:"1px solid rgba(255,255,255,0.08)", margin:"24px 0 18px" }} />
            <h3 style={{ fontFamily:"Orbitron,monospace", color:"#a29bfe", marginBottom:8, fontSize:13 }}>ℹ️ Sistema</h3>
            <div style={{ fontFamily:"Nunito,sans-serif", fontSize:12, color:"rgba(255,255,255,0.35)", lineHeight:2.2 }}>
              <div>📦 Base de datos: <strong style={{ color:"#00f5ff" }}>SQLite local</strong></div>
              <div>📂 Archivo: <strong style={{ color:"#00f5ff" }}>backend/aventura_tablas.db</strong></div>
              <div>💾 Datos guardados en tu computadora</div>
              <div>🔄 Sin necesidad de internet para el juego</div>
              <div>📊 Total alumnos: <strong style={{ color:"#39ff14" }}>{alumnos.length}</strong> | Maestros: <strong style={{ color:"#a29bfe" }}>{maestros.length}</strong></div>
            </div>
          </motion.div>
        )}

        <div style={{ textAlign:"center", marginTop:24 }}>
          <button onClick={cargar} className="btn btn-neon btn-sm">🔄 Actualizar datos</button>
        </div>
      </div>
    </div>
  );
}

// ─── Contenido de impresión (oculto en DOM, usado por window.print) ────────
function ContenidoImpresion({ rep }) {
  const pct = rep.pct || 0;
  const TABLAS_NOMBRES = ["","uno","dos","tres","cuatro","cinco","seis","siete","ocho","nueve","diez"];

  return (
    <div>
      <h1>Reporte de Progreso — Aventura de Tablas Pro</h1>
      <p><strong>Alumno:</strong> {rep.Nombre || "Sin nombre"}</p>
      {rep.Grado && <p><strong>Grado:</strong> {rep.Grado}</p>}
      {rep.Correo && <p><strong>Correo:</strong> {rep.Correo}</p>}
      {rep.Maestro_Nombre && <p><strong>Maestro:</strong> {rep.Maestro_Nombre}</p>}

      <h2>Progreso General</h2>
      <div className="grid">
        <div className="box"><div className="label">Mundos completados</div><div className="val">{rep.mundos || 0} / 10</div></div>
        <div className="box"><div className="label">Avance total</div><div className="val">{pct}%</div></div>
        <div className="box"><div className="label">Tiempo conectado</div><div className="val">{rep.horas>0?`${rep.horas}h `:""}{ rep.mins || 0} min</div></div>
        <div className="box"><div className="label">Monedas ganadas</div><div className="val">🪙 {rep.Monedas || 0}</div></div>
      </div>
      <div className="bar-bg"><div className="bar" style={{ width:`${pct}%` }}/></div>

      {rep.tablasProblema && rep.tablasProblema.length > 0 && (
        <>
          <h2>Tablas que Necesitan Práctica</h2>
          {rep.tablasProblema.map(([tabla, count]) => (
            <div className="tabla-row" key={tabla}>
              <span>Tabla del {tabla} ({TABLAS_NOMBRES[parseInt(tabla)] || tabla})</span>
              <span style={{ color:"#c0392b", fontWeight:"bold" }}>{count} errores</span>
            </div>
          ))}
          <p style={{ fontSize:13, color:"#555", marginTop:8 }}>Recomendación: practicar estas tablas con ejercicios adicionales en casa.</p>
        </>
      )}

      {(!rep.tablasProblema || rep.tablasProblema.length === 0) && (
        <p style={{ color:"green", fontWeight:"bold" }}>✅ ¡Excelente rendimiento! No se detectaron tablas problemáticas.</p>
      )}
    </div>
  );
}
