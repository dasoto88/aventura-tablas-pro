import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import toast from "react-hot-toast";
import axios from "axios";
import { useGameStore } from "../utils/store";
import soundManager from "../utils/sounds";

const API = process.env.REACT_APP_API_URL || "";
const TABS = ["🎮 JUGAR", "📝 REGISTRO", "🎁 DEMO"];

export default function LoginPage() {
  const [tab, setTab] = useState(0);
  const { iniciarSesion, iniciarDemo } = useGameStore();
  const [musicStarted, setMusicStarted] = useState(false);

  const startMusic = () => {
    if (!musicStarted) { soundManager.iniciarMusica(); setMusicStarted(true); }
  };

  return (
    <div className="page" onClick={startMusic}
      style={{ background: "radial-gradient(ellipse at center, #1a0035 0%, #030010 70%)", justifyContent: "center", alignItems: "center" }}>
      <Stars />
      <motion.div initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}
        style={{ width: "100%", maxWidth: 520, padding: "0 16px", zIndex: 10 }}>

        <motion.div animate={{ filter: ["hue-rotate(0deg)", "hue-rotate(360deg)"] }}
          transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
          style={{ textAlign: "center", marginBottom: 32 }}>
          <motion.div animate={{ rotate: [0,-5,5,0], scale:[1,1.05,1] }} transition={{ duration: 3, repeat: Infinity }}
            style={{ fontSize: 72, lineHeight: 1, marginBottom: 8 }}>🦁⚔️🌟</motion.div>
          <h1 style={{
            fontFamily:"Orbitron,monospace", fontSize:"clamp(22px,6vw,38px)", fontWeight:900,
            background:"linear-gradient(90deg,#00f5ff,#ff006e,#FFD700,#00f5ff)", backgroundSize:"300% auto",
            WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent",
            animation:"marquee-bg 4s linear infinite", letterSpacing:3, marginBottom:6,
          }}>AVENTURA DE TABLAS</h1>
          <p style={{ fontFamily:"Rajdhani,sans-serif", color:"rgba(255,255,255,0.5)", fontSize:14, letterSpacing:4, textTransform:"uppercase" }}>
            PRO — EDICIÓN ÉPICA
          </p>
          {!musicStarted && <p style={{ fontFamily:"Nunito,sans-serif", color:"rgba(255,255,255,0.3)", fontSize:12, marginTop:8 }}>🔊 Toca aquí para activar el sonido</p>}
        </motion.div>

        <div className="card card-glow" style={{ background: "rgba(5,8,30,0.92)" }}>
          <div style={{ display:"flex", gap:4, marginBottom:28, background:"rgba(0,0,0,0.3)", borderRadius:14, padding:4 }}>
            {TABS.map((t, i) => (
              <button key={i} onClick={() => setTab(i)} style={{
                flex:1, padding:"10px 4px",
                background: tab===i ? "linear-gradient(135deg,#667eea,#764ba2)" : "transparent",
                border:"none", borderRadius:10, cursor:"pointer",
                color: tab===i ? "#fff" : "rgba(255,255,255,0.45)",
                fontFamily:"Orbitron,monospace", fontSize:"clamp(9px,2.5vw,12px)",
                fontWeight:700, textTransform:"uppercase", transition:"all 0.3s",
              }}>{t}</button>
            ))}
          </div>
          <AnimatePresence mode="wait">
            <motion.div key={tab} initial={{ opacity:0, x:20 }} animate={{ opacity:1, x:0 }} exit={{ opacity:0, x:-20 }} transition={{ duration:0.25 }}>
              {tab === 0 && <TabJugar iniciarSesion={iniciarSesion} />}
              {tab === 1 && <TabRegistro />}
              {tab === 2 && <TabDemo iniciarDemo={iniciarDemo} />}
            </motion.div>
          </AnimatePresence>
        </div>

        <p style={{ textAlign:"center", marginTop:20, color:"rgba(255,255,255,0.2)", fontFamily:"Rajdhani,sans-serif", fontSize:12 }}>
          Aventura de Tablas Pro v2.1 • Para niños de 1° a 3° grado
        </p>
      </motion.div>
    </div>
  );
}

// ─── TAB JUGAR ───────────────────────────────────────────────
function TabJugar({ iniciarSesion }) {
  const [licencia, setLicencia] = useState("");
  const [loading, setLoading] = useState(false);
  const [mostrarRecuperar, setMostrarRecuperar] = useState(false);

  const entrar = async () => {
    if (!licencia.trim()) { toast.error("Escribe tu licencia"); return; }
    setLoading(true);
    try {
      const { data } = await axios.post(
        `${API}/api/validar-licencia`,
        { licencia: licencia.trim() },
        { timeout: 8000 }
      );
      soundManager.logro();
      toast.success(`¡Bienvenido${data.nombre ? " " + data.nombre : ""}! 🎉`);
      iniciarSesion({ ...data, licencia: licencia.trim() });
    } catch (e) {
      soundManager.incorrecto();
      if (e.code === "ECONNABORTED" || e.message?.includes("timeout")) {
        toast.error("⏱ El servidor no responde. ¿Está corriendo el backend en la Terminal 1?");
      } else if (!e.response) {
        toast.error("🔌 No se puede conectar al servidor. Verifica que el backend esté corriendo en puerto 8000.");
      } else {
        const msg = e.response?.data?.detail || "Licencia no válida";
        toast.error(`❌ ${msg}`);
      }
    } finally { setLoading(false); }
  };

  return (
    <div>
      <p style={{ fontFamily:"Nunito,sans-serif", color:"rgba(255,255,255,0.6)", marginBottom:20, textAlign:"center", fontSize:15 }}>
        Ingresa tu código de aventurero para comenzar
      </p>
      <input className="input" placeholder="Tu código de licencia" value={licencia}
        onChange={e => setLicencia(e.target.value)}
        onKeyDown={e => e.key === "Enter" && entrar()}
        style={{ marginBottom:12, textAlign:"center", fontSize:20, letterSpacing:2 }}
      />
      <button className="btn btn-primary btn-full btn-lg" onClick={entrar} disabled={loading} style={{ marginBottom:12 }}>
        {loading ? "Verificando..." : "🚀 ¡COMENZAR AVENTURA!"}
      </button>

      {/* Botón recuperar licencia */}
      <button onClick={() => setMostrarRecuperar(true)}
        style={{ width:"100%", background:"transparent", border:"none", color:"rgba(0,245,255,0.5)",
          fontFamily:"Nunito,sans-serif", fontSize:13, cursor:"pointer", textDecoration:"underline", padding:"4px 0" }}>
        🔑 ¿Olvidaste tu código de licencia?
      </button>

      {/* Modal recuperar */}
      <AnimatePresence>
        {mostrarRecuperar && (
          <ModalRecuperar onClose={() => setMostrarRecuperar(false)} />
        )}
      </AnimatePresence>
    </div>
  );
}

// ─── MODAL RECUPERAR LICENCIA ────────────────────────────────
function ModalRecuperar({ onClose }) {
  const [correo, setCorreo] = useState("");
  const [celular, setCelular] = useState("");
  const [loading, setLoading] = useState(false);
  const [enviado, setEnviado] = useState(null);

  const recuperar = async () => {
    if (!correo.trim() && !celular.trim()) {
      toast.error("Escribe tu correo o celular"); return;
    }
    setLoading(true);
    try {
      const { data } = await axios.post(`${API}/api/recuperar-licencia`, {
        correo: correo.trim(),
        celular: celular.trim(),
      });
      setEnviado(data.correo);
      soundManager.logro();
    } catch (e) {
      const msg = e.response?.data?.detail || "No encontramos tu cuenta";
      toast.error(`❌ ${msg}`);
    } finally { setLoading(false); }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.85)", zIndex:200,
        display:"flex", alignItems:"center", justifyContent:"center", padding:20 }}
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.8, y: 30 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.8, y: 30 }}
        onClick={e => e.stopPropagation()}
        style={{ background:"linear-gradient(135deg,#1a1f4e,#0d1237)", border:"2px solid rgba(108,92,231,0.5)",
          borderRadius:24, padding:32, maxWidth:400, width:"100%", textAlign:"center" }}
      >
        {!enviado ? (
          <>
            <div style={{ fontSize:48, marginBottom:12 }}>🔑</div>
            <h3 style={{ fontFamily:"Orbitron,monospace", color:"#a29bfe", marginBottom:8, fontSize:16 }}>
              RECUPERAR LICENCIA
            </h3>
            <p style={{ fontFamily:"Nunito,sans-serif", color:"rgba(255,255,255,0.55)", fontSize:14, marginBottom:20 }}>
              Escribe el correo o celular con el que te registraste. Te enviaremos tu código.
            </p>
            <input className="input" placeholder="📧 Tu correo electrónico"
              value={correo} onChange={e => setCorreo(e.target.value)} type="email"
              style={{ marginBottom:10 }}
            />
            <p style={{ fontFamily:"Nunito,sans-serif", color:"rgba(255,255,255,0.3)", fontSize:12, margin:"4px 0 10px" }}>— o —</p>
            <input className="input" placeholder="📱 Tu número de celular"
              value={celular} onChange={e => setCelular(e.target.value)} type="tel"
              style={{ marginBottom:20 }}
            />
            <button className="btn btn-primary btn-full" onClick={recuperar} disabled={loading} style={{ marginBottom:10 }}>
              {loading ? "Buscando..." : "📨 ENVIAR MI CÓDIGO"}
            </button>
            <button onClick={onClose}
              style={{ background:"transparent", border:"none", color:"rgba(255,255,255,0.3)",
                fontFamily:"Nunito,sans-serif", fontSize:13, cursor:"pointer" }}>
              Cancelar
            </button>
          </>
        ) : (
          <motion.div initial={{ scale:0 }} animate={{ scale:1 }}>
            <div style={{ fontSize:64, marginBottom:12 }}>📨</div>
            <h3 style={{ fontFamily:"Orbitron,monospace", color:"#00f5ff", marginBottom:8, fontSize:16 }}>
              ¡CORREO ENVIADO!
            </h3>
            <p style={{ fontFamily:"Nunito,sans-serif", color:"rgba(255,255,255,0.6)", fontSize:14, marginBottom:20 }}>
              Enviamos tu código a <strong style={{ color:"#a29bfe" }}>{enviado}</strong>.<br/>
              Revisa tu bandeja de entrada (y spam).
            </p>
            <button className="btn btn-primary btn-full" onClick={onClose}>
              ✅ Entendido
            </button>
          </motion.div>
        )}
      </motion.div>
    </motion.div>
  );
}

// ─── TAB REGISTRO ────────────────────────────────────────────
function TabRegistro() {
  const [form, setForm] = useState({ nombre:"", correo:"", celular:"", escuela:"" });
  const [loading, setLoading] = useState(false);
  const [enviado, setEnviado] = useState(false);

  const enviar = async () => {
    if (!form.nombre || !form.correo || !form.celular || !form.escuela) {
      toast.error("Llena todos los campos"); return;
    }
    setLoading(true);
    try {
      await axios.post(`${API}/api/registro`, form, { timeout: 8000 });
      setEnviado(true);
      soundManager.mundoCompleto();
      toast.success("¡Solicitud enviada! Revisa tu correo 📧");
    } catch (e) {
      if (!e.response) {
        toast.error("🔌 No se puede conectar al servidor. Verifica que el backend esté corriendo.");
      } else {
        const msg = e.response?.data?.detail || "Error al enviar. Intenta de nuevo.";
        toast.error(msg);
      }
    } finally { setLoading(false); }
  };

  if (enviado) return (
    <motion.div initial={{ scale:0 }} animate={{ scale:1 }} style={{ textAlign:"center", padding:20 }}>
      <div style={{ fontSize:64 }}>📨</div>
      <h3 style={{ color:"#00f5ff", fontFamily:"Orbitron,monospace", margin:"16px 0 8px" }}>¡Solicitud enviada!</h3>
      <p style={{ color:"rgba(255,255,255,0.6)", fontFamily:"Nunito,sans-serif", lineHeight:1.6 }}>
        Revisa tu correo. Te enviamos los datos de pago e instrucciones completas.
      </p>
    </motion.div>
  );

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
      {[
        { key:"nombre",  label:"Nombre completo",       type:"text"  },
        { key:"correo",  label:"Correo electrónico",    type:"email" },
        { key:"celular", label:"Número de celular",     type:"tel"   },
        { key:"escuela", label:"Nombre de la escuela",  type:"text"  },
      ].map(f => (
        <input key={f.key} className="input" placeholder={f.label}
          value={form[f.key]} onChange={e => setForm(p => ({...p,[f.key]:e.target.value}))}
          type={f.type}
        />
      ))}
      <div className="tip-box">💳 Costo: <strong>$100 MXN / 30 días</strong> — Te enviamos los datos de pago por correo</div>
      <button className="btn btn-primary btn-full" onClick={enviar} disabled={loading}>
        {loading ? "Enviando..." : "📨 SOLICITAR MI CUENTA"}
      </button>
    </div>
  );
}

// ─── TAB DEMO ────────────────────────────────────────────────
function TabDemo({ iniciarDemo }) {
  return (
    <div style={{ textAlign:"center" }}>
      <div style={{ fontSize:64, marginBottom:16 }}>⏰</div>
      <h3 style={{ fontFamily:"Orbitron,monospace", color:"#FFD700", marginBottom:12, fontSize:18 }}>Demo Gratuita — 3 minutos</h3>
      <p style={{ color:"rgba(255,255,255,0.6)", fontFamily:"Nunito,sans-serif", fontSize:15, lineHeight:1.6, marginBottom:24 }}>
        Prueba el primer mundo sin registrarte. ¡Si te gusta, activa tu cuenta completa!
      </p>
      {["🌍 Bosque Mágico disponible","⚔️ Elige tu avatar","🪙 Gana monedas de prueba","🐗 Lucha contra el boss del bosque"].map(item => (
        <div key={item} style={{ background:"rgba(255,255,255,0.05)", borderRadius:10, padding:"10px 16px",
          color:"rgba(255,255,255,0.75)", fontFamily:"Nunito,sans-serif", textAlign:"left", fontSize:14, marginBottom:6 }}>
          {item}
        </div>
      ))}
      <button className="btn btn-gold btn-full" style={{ marginTop:16 }} onClick={iniciarDemo}>🎁 ¡JUGAR DEMO AHORA!</button>
    </div>
  );
}

// ─── ESTRELLAS DE FONDO ───────────────────────────────────────
function Stars() {
  const stars = Array.from({length:80},(_,i)=>({
    id:i, x:Math.random()*100, y:Math.random()*100,
    size:Math.random()*3+1, delay:Math.random()*3, dur:Math.random()*2+2
  }));
  return (
    <div style={{ position:"fixed", inset:0, overflow:"hidden", pointerEvents:"none" }}>
      {stars.map(s=>(
        <motion.div key={s.id}
          style={{ position:"absolute", left:`${s.x}%`, top:`${s.y}%`, width:s.size, height:s.size, borderRadius:"50%", background:"#fff" }}
          animate={{ opacity:[0.1,0.9,0.1] }}
          transition={{ duration:s.dur, delay:s.delay, repeat:Infinity, ease:"easeInOut" }}
        />
      ))}
    </div>
  );
}
