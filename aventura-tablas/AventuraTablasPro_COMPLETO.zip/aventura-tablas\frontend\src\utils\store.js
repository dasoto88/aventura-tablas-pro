import { create } from "zustand";
import { persist } from "zustand/middleware";
import axios from "axios";

const API = process.env.REACT_APP_API_URL || "";

export const useGameStore = create(
  persist(
    (set, get) => ({
      // ─── AUTH ────────────────────────────────────────────
      licencia: null,
      nombre: null,
      tipoUsuario: null,   // "alumno" | "admin" | "demo" | "maestro"
      fila: null,
      modoDemo: false,
      demoInicio: null,
      sesionInicio: null,  // timestamp para tracking de tiempo
      correo: null,

      // ─── AVATAR ──────────────────────────────────────────
      avatarId: null,
      avatarSeleccionado: false,

      // ─── PROGRESO ────────────────────────────────────────
      mundoActual: 0,
      nivelMax: 1,
      aciertos: 0,
      vidas: 3,
      monedas: 0,
      monedasMundo: 0,
      inventario: [],
      equipado: {},
      rachaActual: 0,
      mundosCompletados: 0,  // contador para emails cada 3 mundos
      fallosTablas: {},       // { "1": 2, "3": 5 } — fallos por tabla

      // ─── ESTADO UI ───────────────────────────────────────
      pagina: "login",
      animacion: "idle",
      mostrarTienda: false,
      mostrarMapa: false,
      boss: {
        activo: false, num1: 0, num2: 0,
        vidaBoss: 0, vidaBossMax: 0, fase: 1,
      },
      logros: [],

      // ─── ACCIONES ────────────────────────────────────────

      iniciarSesion: (datos) => {
        set({
          licencia:       datos.licencia,
          nombre:         datos.nombre,
          correo:         datos.correo || "",
          tipoUsuario:    datos.tipo,
          fila:           datos.fila,
          monedas:        datos.monedas || 0,
          inventario:     datos.inventario ? datos.inventario.split(",").filter(Boolean) : [],
          nivelMax:       datos.nivel_max || 1,
          mundoActual:    Math.min((datos.nivel_max || 1) - 1, 10),
          sesionInicio:   Date.now(),
          pagina: datos.tipo === "admin" || datos.tipo === "maestro"
            ? "admin"
            : "intro",  // ← Intro cinematográfica primero
        });
        // Registrar inicio de sesión en el backend
        if (datos.licencia && datos.tipo !== "demo") {
          axios.post(`${API}/api/sesion/iniciar`, { licencia: datos.licencia }).catch(() => {});
        }
      },

      iniciarDemo: () => {
        set({
          modoDemo: true,
          demoInicio: Date.now(),
          sesionInicio: Date.now(),
          nombre: "Invitado",
          tipoUsuario: "demo",
          pagina: "intro",
          monedas: 0, inventario: [], nivelMax: 1, mundoActual: 0,
        });
      },

      seleccionarAvatar: (avatarId) => {
        set({ avatarId, avatarSeleccionado: true, pagina: "mapa" });
      },

      // Ir al estudio de tabla antes de jugar
      irAMundo: (mundoId) => {
        set({
          mundoActual: mundoId,
          aciertos: 0, vidas: 3, monedasMundo: 0, rachaActual: 0,
          boss: { activo: false, num1: 0, num2: 0, vidaBoss: 0, vidaBossMax: 0, fase: 1 },
          pagina: "estudio_tabla",   // ← Va al estudio primero
          mostrarMapa: false,
          animacion: "idle",
        });
      },

      // Ir directo al juego (desde EstudioTablaPage)
      irAJuego: () => set({ pagina: "juego" }),

      // Volver a enfrentar al boss (desde MundoCompletePage)
      volverABoss: () => {
        set({
          vidas: 3,
          boss: { activo: false, num1: 0, num2: 0, vidaBoss: 0, vidaBossMax: 0, fase: 1 },
          pagina: "boss",
        });
      },

      respuestaCorrecta: (monedasGanadas) => {
        const state = get();
        const nuevaRacha   = state.rachaActual + 1;
        const nuevosAciertos = state.aciertos + 1;
        const totalMonedas   = state.monedas + monedasGanadas;
        const monedoActual   = state.monedasMundo + monedasGanadas;

        set({
          aciertos:     nuevosAciertos,
          monedas:      totalMonedas,
          monedasMundo: monedoActual,
          vidas:        3,
          rachaActual:  nuevaRacha,
          animacion:    "win",
        });

        if (nuevosAciertos >= 10) {
          setTimeout(() => {
            const mundo = require("./gameData").MUNDOS[state.mundoActual];
            set({
              boss: {
                activo:    true,
                num1:      mundo.esSupremo ? Math.floor(Math.random() * 10) + 1 : mundo.boss.num1,
                num2:      mundo.esSupremo ? Math.floor(Math.random() * 10) + 1 : mundo.boss.num2,
                vidaBoss:  mundo.bossVida,
                vidaBossMax: mundo.bossVida,
                fase: 1,
              },
            });
          }, 800);
        }
        if (!get().modoDemo) get().guardarProgreso();
      },

      respuestaIncorrecta: () => {
        const state = get();
        const nuevasVidas = state.vidas - 1;
        const tabla = require("./gameData").MUNDOS[state.mundoActual]?.tabla || 1;

        // Registrar fallo en esa tabla
        const fallos = { ...state.fallosTablas };
        fallos[tabla] = (fallos[tabla] || 0) + 1;

        set({
          vidas:       nuevasVidas,
          animacion:   "sad",
          rachaActual: 0,
          fallosTablas: fallos,
        });

        if (nuevasVidas <= 0) {
          setTimeout(() => {
            set({
              vidas: 3, aciertos: 0, monedasMundo: 0, rachaActual: 0,
              monedas: Math.max(0, state.monedas - state.monedasMundo),
              boss: { activo: false, num1: 0, num2: 0, vidaBoss: 0, vidaBossMax: 0, fase: 1 },
              animacion: "sad",
              // NO cambia de página — JuegoPage mostrará el modal de elección
            });
          }, 2000);
        }
      },

      atacarBoss: (correcto) => {
        const state = get();
        if (correcto) {
          const nuevaVida = state.boss.vidaBoss - 1;
          if (nuevaVida <= 0) {
            const mundoData = require("./gameData").MUNDOS[state.mundoActual];
            const nuevasMonedas = state.monedas + mundoData.premio;
            const nuevoNivel    = Math.max(state.nivelMax, state.mundoActual + 2);
            const nuevosMundosCompletados = state.mundosCompletados + 1;
            set({
              boss:             { ...state.boss, vidaBoss: 0, activo: false },
              monedas:          nuevasMonedas,
              animacion:        "celebrate",
              pagina:           "mundo_completo",
              nivelMax:         nuevoNivel,
              mundosCompletados: nuevosMundosCompletados,
            });
            if (!state.modoDemo) {
              setTimeout(() => get().guardarProgreso(nuevosMundosCompletados), 500);
            }
          } else {
            set({ boss: { ...state.boss, vidaBoss: nuevaVida } });
          }
        } else {
          const nuevasVidas = state.vidas - 1;
          set({ vidas: nuevasVidas, animacion: "sad" });
          if (nuevasVidas <= 0) {
            setTimeout(() => {
              set({
                vidas: 3, aciertos: 0, monedasMundo: 0,
                monedas: Math.max(0, state.monedas - state.monedasMundo),
                boss: { activo: false, num1: 0, num2: 0, vidaBoss: 0, vidaBossMax: 0, fase: 1 },
                pagina: "juego",
              });
            }, 2500);
          }
        }
      },

      comprarItem: (item) => {
        const state = get();
        if (state.monedas < item.precio) return false;
        if (state.inventario.includes(item.id)) return false;
        const nuevasMonedas = state.monedas - item.precio;
        const nuevoInv = [...state.inventario, item.id];
        set({ monedas: nuevasMonedas, inventario: nuevoInv });
        if (!state.modoDemo) setTimeout(() => get().guardarProgreso(), 300);
        return true;
      },

      equiparItem: (tipo, itemId) => {
        set((state) => ({ equipado: { ...state.equipado, [tipo]: itemId } }));
      },

      guardarProgreso: async (mundosCompletadosOverride) => {
        const state = get();
        const mundosTotal = mundosCompletadosOverride ?? state.mundosCompletados;
        const tiempoMin = state.sesionInicio
          ? Math.round((Date.now() - state.sesionInicio) / 60000)
          : 0;
        try {
          await axios.post(`${API}/api/actualizar-progreso`, {
            licencia:           state.licencia,
            monedas:            state.monedas,
            inventario:         state.inventario.join(","),
            nivel_max:          state.nivelMax,
            nombre:             state.nombre,
            mundos_completados: mundosTotal,
            fallos_tablas:      JSON.stringify(state.fallosTablas || {}),
            tiempo_min:         tiempoMin,
          });
        } catch (e) {
          console.error("Error guardando progreso:", e);
        }
      },

      cerrarSesion: () => {
        const state = get();
        // Registrar fin de sesión
        if (state.licencia && state.tipoUsuario !== "demo") {
          const tiempoMin = state.sesionInicio
            ? Math.round((Date.now() - state.sesionInicio) / 60000)
            : 0;
          axios.post(`${API}/api/sesion/terminar`, {
            licencia: state.licencia,
            tiempo_min: tiempoMin,
          }).catch(() => {});
        }
        set({
          licencia: null, nombre: null, correo: null, tipoUsuario: null, fila: null,
          modoDemo: false, demoInicio: null, sesionInicio: null,
          avatarId: null, avatarSeleccionado: false,
          mundoActual: 0, nivelMax: 1,
          aciertos: 0, vidas: 3, monedas: 0, monedasMundo: 0,
          inventario: [], equipado: {}, rachaActual: 0,
          mundosCompletados: 0, fallosTablas: {},
          pagina: "login", animacion: "idle",
          boss: { activo: false, num1: 0, num2: 0, vidaBoss: 0, vidaBossMax: 0, fase: 1 },
          logros: [],
        });
      },

      setAnimacion: (anim) => set({ animacion: anim }),
      setPagina:    (p)    => set({ pagina: p }),
    }),
    {
      name: "aventura-tablas-store-v2",
      partialize: (state) => ({
        licencia: state.licencia, nombre: state.nombre, correo: state.correo,
        tipoUsuario: state.tipoUsuario, fila: state.fila,
        mundoActual: state.mundoActual, nivelMax: state.nivelMax,
        monedas: state.monedas, inventario: state.inventario, equipado: state.equipado,
        avatarId: state.avatarId, logros: state.logros,
        mundosCompletados: state.mundosCompletados, fallosTablas: state.fallosTablas,
      }),
    }
  )
);
