// ============================================================
//  AVENTURA DE TABLAS PRO — SISTEMA DE VOZ (Web Speech API)
//  Usa la voz del sistema, funciona sin internet, sin librerías
// ============================================================

class VoiceManager {
  constructor() {
    this.enabled = true;
    this.synth = null;
    this.voices = [];
    this._stopFlag = false;
    this._init();
  }

  _init() {
    if (typeof window === "undefined" || !window.speechSynthesis) return;
    this.synth = window.speechSynthesis;
    const load = () => {
      this.voices = this.synth.getVoices();
    };
    load();
    this.synth.onvoiceschanged = load;
  }

  _getVoz() {
    if (!this.voices.length) this.voices = this.synth?.getVoices() || [];
    // Prioridad: español México > español cualquiera > primera disponible
    return (
      this.voices.find(v => v.lang === "es-MX") ||
      this.voices.find(v => v.lang === "es-US") ||
      this.voices.find(v => v.lang.startsWith("es")) ||
      this.voices[0] ||
      null
    );
  }

  // ─── Hablar texto simple (fire & forget) ──────────────────
  hablar(texto, opciones = {}) {
    if (!this.enabled || !this.synth) return;
    this.synth.cancel();
    const utt = new SpeechSynthesisUtterance(texto);
    utt.lang    = "es-MX";
    utt.rate    = opciones.velocidad  || 0.85;
    utt.pitch   = opciones.tono       || 1.1;
    utt.volume  = opciones.volumen    || 0.95;
    const voz = this._getVoz();
    if (voz) utt.voice = voz;
    this.synth.speak(utt);
    return utt;
  }

  // ─── Hablar y esperar a que termine ───────────────────────
  hablarYEsperar(texto, opciones = {}) {
    return new Promise(resolve => {
      if (!this.enabled || !this.synth) { resolve(); return; }
      this.synth.cancel();
      const utt = new SpeechSynthesisUtterance(texto);
      utt.lang    = "es-MX";
      utt.rate    = opciones.velocidad  || 0.82;
      utt.pitch   = opciones.tono       || 1.1;
      utt.volume  = opciones.volumen    || 0.95;
      const voz = this._getVoz();
      if (voz) utt.voice = voz;
      utt.onend   = resolve;
      utt.onerror = resolve;
      this.synth.speak(utt);
    });
  }

  // ─── Leer tabla completa (con callback por cada hecho) ────
  async leerTabla(tabla, { onHecho, onTerminado, velocidad = 0.82 } = {}) {
    this._stopFlag = false;
    if (!this.enabled || !this.synth) { onTerminado?.(); return; }

    await this.hablarYEsperar(
      `¡Muy bien! Ahora vamos a aprender la tabla del ${tabla}. ¡Repite conmigo!`,
      { velocidad }
    );

    for (let i = 1; i <= 10; i++) {
      if (this._stopFlag) break;
      const resultado = tabla * i;
      onHecho?.(i); // resaltar la fila i en la UI
      await this.hablarYEsperar(
        `${tabla} por ${i}... igual a... ${resultado}`,
        { velocidad }
      );
      await this._esperar(350);
    }

    if (!this._stopFlag) {
      await this._esperar(400);
      await this.hablarYEsperar(
        `¡Excelente! Ya conoces la tabla del ${tabla}. ¡Ahora a practicarla en el juego!`,
        { velocidad }
      );
    }
    onTerminado?.();
  }

  // ─── Leer un solo hecho ───────────────────────────────────
  pronunciarHecho(n1, n2) {
    const res = n1 * n2;
    this.hablar(`${n1} por ${n2}, igual a ${res}`);
  }

  // ─── Mensajes de motivación ───────────────────────────────
  motivar(tipo) {
    const frases = {
      correcto:  ["¡Muy bien!", "¡Correcto!", "¡Eso es!", "¡Excelente!", "¡Genial!"],
      incorrecto:["¡Casi! Sigue intentando.", "¡No te rindas!", "¡Tú puedes!"],
      boss:      ["¡El monstruo se acerca! ¡Responde rápido!","¡Ataca con tus tablas!"],
      victory:   ["¡Ganaste! ¡Eres un campeón!","¡Lo lograste! ¡Increíble!"],
    };
    const lista = frases[tipo] || frases.correcto;
    this.hablar(lista[Math.floor(Math.random() * lista.length)]);
  }

  // ─── Intro del mundo ──────────────────────────────────────
  async introMundo(nombreMundo, tabla) {
    await this.hablarYEsperar(
      `¡Bienvenido al ${nombreMundo}! Aquí aprenderás la tabla del ${tabla}. ¡Vamos con todo!`
    );
  }

  // ─── Parar todo ───────────────────────────────────────────
  detener() {
    this._stopFlag = true;
    this.synth?.cancel();
  }

  toggle() {
    this.enabled = !this.enabled;
    if (!this.enabled) this.detener();
    return this.enabled;
  }

  _esperar(ms) {
    return new Promise(r => setTimeout(r, ms));
  }
}

const voiceManager = new VoiceManager();
export default voiceManager;
