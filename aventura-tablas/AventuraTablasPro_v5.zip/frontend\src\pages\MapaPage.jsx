import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useGameStore } from "../utils/store";
import { MUNDOS, AVATARES } from "../utils/gameData";

export default function MapaPage() {
  const { mundoActual, nivelMax, irAMundo, nombre, avatarId, monedas, modoDemo } = useGameStore();
  const [hoveredMundo, setHoveredMundo] = useState(null);
  const [showTooltip, setShowTooltip] = useState(null);
  const avatar = AVATARES.find(a => a.id === avatarId) || AVATARES[0];

  // En demo solo el primer mundo
  const mundosDisponibles = modoDemo ? 1 : nivelMax;

  // El avatar siempre se muestra en el mundo frontera (el siguiente por conquistar)
  // No en mundoActual (que puede ser uno viejo que reejugó)
  const mundoFrontera = Math.min(nivelMax - 1, MUNDOS.length - 1);

  return (
    <div className="page" style={{
      background: "radial-gradient(ellipse at top, #0d002b 0%, #030010 70%)",
      padding: 0,
      minHeight: "100vh",
    }}>
      {/* HUD */}
      <div className="hud">
        <div className="hud-item">
          <span style={{ fontSize: 24 }}>{avatar.emoji}</span>
          <span className="hud-value" style={{ fontFamily: "Nunito, sans-serif", fontSize: 14 }}>{nombre}</span>
        </div>
        <div className="hud-item">
          <span>🪙</span>
          <span className="hud-value" style={{ color: "#FFD700" }}>{monedas.toLocaleString()}</span>
        </div>
        <div className="hud-item">
          <span style={{ fontSize: 14, fontFamily: "Rajdhani, sans-serif", color: "rgba(255,255,255,0.5)" }}>
            Mundos: {Math.min(mundosDisponibles, MUNDOS.length)}/{MUNDOS.length}
          </span>
        </div>
        {modoDemo && <span style={{ marginLeft: "auto", color: "#FFD700", fontFamily: "Orbitron, monospace", fontSize: 11 }}>🎮 DEMO</span>}
      </div>

      {/* Título */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        style={{ textAlign: "center", padding: "24px 16px 16px" }}
      >
        <h1 style={{
          fontFamily: "Orbitron, monospace",
          fontSize: "clamp(20px, 5vw, 36px)",
          fontWeight: 900,
          background: "linear-gradient(90deg, #FFD700, #ff006e, #00f5ff)",
          WebkitBackgroundClip: "text",
          WebkitTextFillColor: "transparent",
        }}>
          🗺️ MAPA DE AVENTURAS
        </h1>
        <p style={{ color: "rgba(255,255,255,0.45)", fontFamily: "Nunito, sans-serif", fontSize: 14, marginTop: 6 }}>
          Elige un mundo para comenzar o continuar tu aventura
        </p>
      </motion.div>

      {/* Path de mundos tipo Mario */}
      <div style={{ padding: "0 16px 32px", maxWidth: 900, margin: "0 auto", position: "relative" }}>
        {/* Línea conectora */}
        <svg style={{ position: "absolute", inset: 0, width: "100%", height: "100%", pointerEvents: "none", zIndex: 0 }} viewBox="0 0 900 1200" preserveAspectRatio="none">
          <defs>
            <linearGradient id="pathGrad" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#00f5ff" stopOpacity="0.4" />
              <stop offset="100%" stopColor="#ff006e" stopOpacity="0.4" />
            </linearGradient>
          </defs>
          <path d="M450,60 Q700,120 450,200 Q200,280 450,360 Q700,440 450,520 Q200,600 450,680 Q700,760 450,840 Q200,920 450,1000 Q700,1080 450,1160" stroke="url(#pathGrad)" strokeWidth="4" fill="none" strokeDasharray="12,8" />
        </svg>

        {/* Grid de mundos */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "16px", position: "relative", zIndex: 1 }}>
          {MUNDOS.map((mundo, i) => {
            const desbloqueado = i < mundosDisponibles;
            const completado = i < mundosDisponibles - 1;
            const esActual = i === mundoFrontera;   // avatar en la frontera, no en el jugado
            const esSupremo = mundo.esSupremo;

            if (esSupremo) {
              // Mundo supremo ocupa 3 columnas
              return (
                <motion.div
                  key={mundo.id}
                  initial={{ opacity: 0, scale: 0.5 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: i * 0.05, type: "spring" }}
                  style={{ gridColumn: "1 / -1" }}
                >
                  <MundoCardSupremo
                    mundo={mundo}
                    desbloqueado={desbloqueado}
                    completado={completado}
                    esActual={esActual}
                    onClic={() => desbloqueado && irAMundo(i)}
                  />
                </motion.div>
              );
            }

            return (
              <motion.div
                key={mundo.id}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.06, type: "spring", stiffness: 150 }}
              >
                <MundoCard
                  mundo={mundo}
                  desbloqueado={desbloqueado}
                  completado={completado}
                  esActual={esActual}
                  hovered={hoveredMundo === i}
                  onHover={() => setHoveredMundo(i)}
                  onLeave={() => setHoveredMundo(null)}
                  onClic={() => desbloqueado && irAMundo(i)}
                  avatarEmoji={esActual ? avatar.emoji : null}
                />
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Leyenda */}
      <div style={{
        display: "flex", gap: 16, justifyContent: "center", flexWrap: "wrap",
        padding: "16px 16px 32px",
        fontFamily: "Nunito, sans-serif", fontSize: 13,
        color: "rgba(255,255,255,0.45)"
      }}>
        <span>✅ Completado</span>
        <span style={{ color: "#00f5ff" }}>🎯 Disponible</span>
        <span style={{ opacity: 0.4 }}>🔒 Bloqueado</span>
        <span style={{ color: "#FFD700" }}>👑 Supremo</span>
      </div>
    </div>
  );
}

// ─── MUNDO CARD ───────────────────────────────────────────────
function MundoCard({ mundo, desbloqueado, completado, esActual, hovered, onHover, onLeave, onClic, avatarEmoji }) {
  return (
    <div
      className={`mundo-card ${!desbloqueado ? "bloqueado" : ""} ${completado ? "completado" : ""} ${esActual ? "actual" : ""}`}
      onMouseEnter={onHover}
      onMouseLeave={onLeave}
      onClick={onClic}
      style={{
        background: desbloqueado
          ? `linear-gradient(135deg, ${mundo.colorOscuro}cc, ${mundo.color}33)`
          : "rgba(20,20,40,0.5)",
        borderColor: esActual ? mundo.color : completado ? "#39ff14" : desbloqueado ? `${mundo.color}66` : "rgba(255,255,255,0.1)",
        boxShadow: esActual ? `0 0 25px ${mundo.color}66` : "none",
        minHeight: 140,
        position: "relative",
        overflow: "hidden",
      }}
    >
      {/* Avatar encima del mundo actual */}
      {avatarEmoji && (
        <motion.div
          animate={{ y: [0, -8, 0] }}
          transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
          style={{
            position: "absolute", top: -18, left: "50%", transform: "translateX(-50%)",
            fontSize: 28, zIndex: 10, filter: `drop-shadow(0 0 8px ${mundo.color})`,
          }}
        >
          {avatarEmoji}
        </motion.div>
      )}

      {/* Lock overlay */}
      {!desbloqueado && (
        <div style={{
          position: "absolute", inset: 0, display: "flex", alignItems: "center",
          justifyContent: "center", background: "rgba(0,0,0,0.5)", borderRadius: "inherit", zIndex: 5
        }}>
          <div style={{ fontSize: 36 }}>🔒</div>
        </div>
      )}

      {/* Número */}
      <div style={{
        position: "absolute", top: 8, left: 10,
        fontFamily: "Orbitron, monospace", fontSize: 11,
        color: "rgba(255,255,255,0.35)",
      }}>
        #{mundo.id + 1}
      </div>

      {/* Completado */}
      {completado && (
        <div style={{ position: "absolute", top: 8, right: 10, fontSize: 16 }}>✅</div>
      )}

      <div style={{ textAlign: "center", paddingTop: avatarEmoji ? 16 : 8 }}>
        <motion.div
          animate={desbloqueado && hovered ? { rotate: [0, -15, 15, 0], scale: [1, 1.2, 1] } : {}}
          transition={{ duration: 0.5 }}
          style={{ fontSize: 40, marginBottom: 8 }}
        >
          {mundo.emoji}
        </motion.div>
        <div style={{
          fontFamily: "Orbitron, monospace", fontSize: 12, fontWeight: 700,
          color: desbloqueado ? "#fff" : "rgba(255,255,255,0.4)", marginBottom: 4,
        }}>
          {mundo.nombre}
        </div>
        <div style={{ fontFamily: "Nunito, sans-serif", fontSize: 11, color: mundo.color }}>
          Tabla del {mundo.tabla}
        </div>
        {desbloqueado && (
          <div style={{ marginTop: 8, fontFamily: "Nunito, sans-serif", fontSize: 10, color: "#FFD700" }}>
            🪙 {mundo.premio} de premio
          </div>
        )}
        {/* Boss */}
        {desbloqueado && !completado && (
          <div style={{ marginTop: 6, fontSize: 14 }}>
            {mundo.bossEmoji} <span style={{ fontFamily: "Nunito, sans-serif", fontSize: 10, color: "rgba(255,255,255,0.45)" }}>{mundo.bossNombre}</span>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── MUNDO SUPREMO ────────────────────────────────────────────
function MundoCardSupremo({ mundo, desbloqueado, completado, esActual, onClic }) {
  return (
    <motion.div
      animate={desbloqueado ? { boxShadow: ["0 0 20px rgba(255,214,0,0.3)", "0 0 60px rgba(255,214,0,0.7)", "0 0 20px rgba(255,214,0,0.3)"] } : {}}
      transition={{ duration: 2, repeat: Infinity }}
      onClick={onClic}
      style={{
        background: desbloqueado
          ? "linear-gradient(135deg, #3d0020 0%, #7b0034 40%, #FFD700 100%)"
          : "rgba(20,20,40,0.5)",
        border: `3px solid ${desbloqueado ? "#FFD700" : "rgba(255,255,255,0.1)"}`,
        borderRadius: 24, padding: 32, textAlign: "center",
        cursor: desbloqueado ? "pointer" : "default",
        position: "relative", overflow: "hidden",
        filter: desbloqueado ? "none" : "grayscale(0.8) opacity(0.5)",
      }}
    >
      {!desbloqueado && (
        <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", background: "rgba(0,0,0,0.6)", borderRadius: "inherit", zIndex: 5, gap: 8 }}>
          <div style={{ fontSize: 48 }}>🔒</div>
          <p style={{ color: "rgba(255,255,255,0.5)", fontFamily: "Nunito, sans-serif", fontSize: 13 }}>Completa los 10 mundos para desbloquear</p>
        </div>
      )}

      {desbloqueado && (
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          style={{ position: "absolute", inset: -50, background: "conic-gradient(from 0deg, transparent 70%, rgba(255,214,0,0.15) 80%, transparent 90%)", pointerEvents: "none" }}
        />
      )}

      <div style={{ position: "relative", zIndex: 1 }}>
        <motion.div
          animate={desbloqueado ? { scale: [1, 1.1, 1], rotate: [0, -5, 5, 0] } : {}}
          transition={{ duration: 3, repeat: Infinity }}
          style={{ fontSize: 72, marginBottom: 12 }}
        >
          {mundo.emoji}
        </motion.div>
        <h2 style={{ fontFamily: "Orbitron, monospace", fontSize: 22, fontWeight: 900, color: "#FFD700", marginBottom: 8, letterSpacing: 3 }}>
          {mundo.nombre}
        </h2>
        <p style={{ fontFamily: "Nunito, sans-serif", color: "rgba(255,255,255,0.7)", fontSize: 15, marginBottom: 12 }}>
          {mundo.descripcion}
        </p>
        <div style={{ display: "flex", justifyContent: "center", gap: 24, flexWrap: "wrap" }}>
          <div style={{ textAlign: "center" }}>
            <div style={{ fontSize: 28 }}>{mundo.bossEmoji}</div>
            <div style={{ fontFamily: "Nunito, sans-serif", fontSize: 12, color: "#ff006e" }}>{mundo.bossNombre}</div>
          </div>
          <div style={{ textAlign: "center" }}>
            <div style={{ fontFamily: "Orbitron, monospace", fontSize: 22, color: "#FFD700" }}>🪙 {mundo.premio.toLocaleString()}</div>
            <div style={{ fontFamily: "Nunito, sans-serif", fontSize: 11, color: "rgba(255,255,255,0.4)" }}>Monedas de premio</div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
