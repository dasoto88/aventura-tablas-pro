"""
Aventura de Tablas Pro v3.0 — Backend SQLite completo
Incluye: sesiones, maestros/alumnos, reportes, emails automáticos, auto-códigos
"""
from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
import sqlite3, os, json, re, random, string, smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime, timedelta
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

app = FastAPI(title="Aventura de Tablas API", version="3.0.0")
app.add_middleware(
    CORSMiddleware, allow_origins=["*"], allow_credentials=True,
    allow_methods=["*"], allow_headers=["*"]
)

EMAIL_FROM = os.getenv("EMAIL_REMITENTE", "pixelimpresorasap@gmail.com")
EMAIL_PASS = os.getenv("EMAIL_PASSWORD", "")
LINK_MP    = os.getenv("LINK_MERCADO_PAGO", "https://mpago.la/1HSsTdv")
DATOS_BBVA = os.getenv("DATOS_TRANSFERENCIA",
    "Banco: BBVA | Cuenta: 4152314169570341 | Titular: David Soto Beltran | Concepto: AventuraTablas + Nombre alumno")

DB_PATH = Path(__file__).parent / "aventura_tablas.db"

# ─── BASE DE DATOS ────────────────────────────────────────────
def get_db():
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    try:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS config (
                key   TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS Licencias (
                id                INTEGER PRIMARY KEY AUTOINCREMENT,
                Licencia          TEXT UNIQUE NOT NULL,
                Activa            TEXT NOT NULL DEFAULT 'NO',
                Tipo              TEXT NOT NULL DEFAULT 'alumno',
                Nombre            TEXT DEFAULT '',
                Correo            TEXT DEFAULT '',
                Celular           TEXT DEFAULT '',
                Monedas           INTEGER DEFAULT 0,
                Inventario        TEXT DEFAULT '',
                Nivel_Max         INTEGER DEFAULT 1,
                Fecha_Vence       TEXT DEFAULT '',
                Grado             TEXT DEFAULT '',
                Maestro_Licencia  TEXT DEFAULT '',
                Mundos_Completados INTEGER DEFAULT 0,
                Fallos_Tablas     TEXT DEFAULT '{}',
                Tiempo_Total_Min  INTEGER DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS Solicitudes (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                Fecha       TEXT NOT NULL,
                Nombre      TEXT NOT NULL,
                Correo      TEXT NOT NULL,
                Celular     TEXT NOT NULL,
                Escuela     TEXT NOT NULL,
                Tipo        TEXT DEFAULT 'alumno',
                Grado       TEXT DEFAULT '',
                Num_Alumnos INTEGER DEFAULT 0,
                Estado      TEXT DEFAULT 'Pendiente'
            );
            CREATE TABLE IF NOT EXISTS Sesiones (
                id        INTEGER PRIMARY KEY AUTOINCREMENT,
                Licencia  TEXT NOT NULL,
                Inicio    TEXT NOT NULL,
                Fin       TEXT DEFAULT '',
                Tiempo_Min INTEGER DEFAULT 0,
                Fecha     TEXT NOT NULL
            );
        """)
        # Migraciones seguras para bases de datos existentes
        for alter in [
            "ALTER TABLE Licencias ADD COLUMN Grado TEXT DEFAULT ''",
            "ALTER TABLE Licencias ADD COLUMN Maestro_Licencia TEXT DEFAULT ''",
            "ALTER TABLE Licencias ADD COLUMN Mundos_Completados INTEGER DEFAULT 0",
            "ALTER TABLE Licencias ADD COLUMN Fallos_Tablas TEXT DEFAULT '{}'",
            "ALTER TABLE Licencias ADD COLUMN Tiempo_Total_Min INTEGER DEFAULT 0",
            "ALTER TABLE Solicitudes ADD COLUMN Tipo TEXT DEFAULT 'alumno'",
            "ALTER TABLE Solicitudes ADD COLUMN Grado TEXT DEFAULT ''",
            "ALTER TABLE Solicitudes ADD COLUMN Num_Alumnos INTEGER DEFAULT 0",
        ]:
            try: conn.execute(alter)
            except: pass

        # Admin por defecto
        if not conn.execute("SELECT value FROM config WHERE key='admin_licencia'").fetchone():
            conn.execute("INSERT INTO config (key,value) VALUES ('admin_licencia','admindasoto88')")
            conn.execute("""
                INSERT OR IGNORE INTO Licencias (Licencia,Activa,Tipo,Nombre,Correo)
                VALUES ('admindasoto88','SI','admin','Admin',?)
            """, (EMAIL_FROM,))
        conn.commit()
        print(f"[DB] Base de datos lista en {DB_PATH}")
    finally:
        conn.close()

init_db()

def get_admin_licencia() -> str:
    conn = get_db()
    try:
        row = conn.execute("SELECT value FROM config WHERE key='admin_licencia'").fetchone()
        return row["value"] if row else "admindasoto88"
    finally:
        conn.close()

# ─── MODELOS ──────────────────────────────────────────────────
class ValidarLicencia(BaseModel):
    licencia: str

class SolicitudRegistro(BaseModel):
    nombre: str
    correo: str
    celular: str
    escuela: str
    tipo: Optional[str] = "alumno"
    grado: Optional[str] = ""
    num_alumnos: Optional[int] = 0

class ActualizarProgreso(BaseModel):
    licencia: str
    monedas: int
    inventario: str
    nivel_max: int
    nombre: Optional[str] = None
    mundos_completados: Optional[int] = None
    fallos_tablas: Optional[str] = None
    tiempo_min: Optional[int] = None

class CrearLicencia(BaseModel):
    codigo: str
    tipo: str
    nombre: Optional[str] = ""
    correo: Optional[str] = ""
    celular: Optional[str] = ""
    grado: Optional[str] = ""
    maestro_licencia: Optional[str] = ""

class EditarLicencia(BaseModel):
    licencia: str
    nombre: Optional[str] = ""
    correo: Optional[str] = ""
    celular: Optional[str] = ""
    monedas: Optional[int] = 0
    nivel_max: Optional[int] = 1
    grado: Optional[str] = ""
    maestro_licencia: Optional[str] = ""

class AccionLicencia(BaseModel):
    codigo: str

class CambiarAdminLicencia(BaseModel):
    licencia_actual: str
    licencia_nueva: str

class RecuperarLicencia(BaseModel):
    correo: Optional[str] = ""
    celular: Optional[str] = ""

class IniciarSesion(BaseModel):
    licencia: str

class TerminarSesion(BaseModel):
    licencia: str
    tiempo_min: Optional[int] = 0

class GenerarCodigo(BaseModel):
    nombre: str
    tipo: str

# ─── EMAIL ────────────────────────────────────────────────────
def enviar_correo(destinatario: str, asunto: str, html: str) -> bool:
    try:
        msg = MIMEMultipart("alternative")
        msg["From"]    = EMAIL_FROM
        msg["To"]      = destinatario
        msg["Subject"] = asunto
        msg.attach(MIMEText(html, "html"))
        with smtplib.SMTP("smtp.gmail.com", 587) as s:
            s.starttls()
            s.login(EMAIL_FROM, EMAIL_PASS)
            s.send_message(msg)
        print(f"[Email OK] → {destinatario}")
        return True
    except Exception as e:
        print(f"[Email Error] {e}")
        return False

# ─── TEMPLATES ────────────────────────────────────────────────
def _base(contenido: str) -> str:
    return f"""<!DOCTYPE html><html><head><meta charset="UTF-8">
<style>body{{margin:0;padding:0;background:#030010;font-family:'Segoe UI',Arial,sans-serif;}}
.wrap{{max-width:600px;margin:0 auto;padding:30px 16px;}}
.card{{background:linear-gradient(135deg,#1a1f4e,#0d1237);border-radius:24px;overflow:hidden;border:2px solid #00f5ff22;}}
.hero{{padding:36px;text-align:center;}}.body{{padding:32px;}}
h1{{font-family:monospace;font-size:26px;font-weight:900;margin:0 0 6px;letter-spacing:3px;}}
p{{color:#b0b8ff;line-height:1.7;margin:10px 0;font-size:15px;}}
.btn{{display:inline-block;padding:14px 32px;border-radius:14px;text-decoration:none;font-weight:bold;font-size:16px;margin:8px 4px;}}
.box{{border-radius:16px;padding:20px 24px;margin:18px 0;}}
.box-cyan{{background:rgba(0,245,255,0.08);border:2px solid rgba(0,245,255,0.3);}}
.box-gold{{background:rgba(255,214,0,0.08);border:2px solid rgba(255,214,0,0.4);}}
.box-pink{{background:rgba(255,0,110,0.08);border:2px solid rgba(255,0,110,0.3);}}
.box-green{{background:rgba(57,255,20,0.08);border:2px solid rgba(57,255,20,0.3);}}
.box-purple{{background:rgba(108,92,231,0.12);border:2px solid rgba(162,155,254,0.4);}}
.label{{font-size:11px;color:#00f5ff;text-transform:uppercase;letter-spacing:2px;margin-bottom:6px;}}
.code{{font-family:monospace;font-size:28px;font-weight:900;color:#fff;background:rgba(0,0,0,0.5);padding:14px 24px;border-radius:12px;letter-spacing:5px;display:inline-block;margin:10px 0;border:2px solid rgba(255,214,0,0.4);}}
ol li{{color:#b0b8ff;line-height:2.2;font-size:14px;}}
.bar-bg{{background:rgba(255,255,255,0.1);border-radius:6px;height:14px;margin:8px 0;}}
.bar{{background:linear-gradient(90deg,#39ff14,#00b894);border-radius:6px;height:14px;}}
.footer{{text-align:center;padding:20px;color:#3a4060;font-size:12px;}}
</style></head>
<body><div class="wrap"><div class="card">{contenido}</div>
<div class="footer">Aventura de Tablas Pro v3.0 • {EMAIL_FROM}</div>
</div></body></html>"""

def email_solicitud(nombre: str, es_maestro: bool = False) -> str:
    bbva = DATOS_BBVA.replace("|","<br>")
    tipo_txt = "tu salón" if es_maestro else "tu hijo/a"
    return _base(f"""
<div class="hero" style="background:linear-gradient(135deg,#ff006e,#8338ec,#3a86ff);">
  <div style="font-size:64px;margin-bottom:10px;">🦁⚔️🌟</div>
  <h1 style="color:#fff;">¡SOLICITUD RECIBIDA!</h1>
</div>
<div class="body">
  <p>¡Hola <strong style="color:#00f5ff;">{nombre}</strong>! 👋</p>
  <p>Recibimos tu solicitud para <strong>Aventura de Tablas Pro</strong> para {tipo_txt}. Para activar la cuenta, realiza el pago:</p>
  <div class="box box-gold">
    <div class="label">💳 Mercado Pago</div>
    <a href="{LINK_MP}" class="btn" style="background:linear-gradient(135deg,#00b4d8,#0077b6);color:#fff;">👉 Pagar con Mercado Pago</a>
  </div>
  <div class="box box-cyan">
    <div class="label">🏦 Transferencia BBVA</div>
    <p style="margin:0;">{bbva}</p>
  </div>
  <div class="box box-pink">
    <div class="label">📋 Pasos siguientes</div>
    <ol>
      <li>Realiza el pago por cualquier método</li>
      <li>Envía el comprobante a <strong style="color:#00f5ff;">{EMAIL_FROM}</strong></li>
      <li>En menos de <strong>24 horas</strong> recibirás tu código 🎉</li>
    </ol>
  </div>
</div>""")

def email_activacion(nombre: str, licencia: str, fecha_vence: str,
                     maestro_nombre: str = "", grado: str = "") -> str:
    extra = ""
    if maestro_nombre:
        extra = f"""
  <div class="box box-purple">
    <div class="label">🎓 Información del Maestro</div>
    <p style="margin:0;"><strong style="color:#a29bfe;">{maestro_nombre}</strong></p>
    {f'<p style="margin:4px 0;color:#b0b8ff;">Grado: {grado}</p>' if grado else ""}
    <p style="margin:4px 0;color:#b0b8ff;">Tu maestro puede ver tu avance y progreso en el juego.</p>
  </div>"""
    return _base(f"""
<div class="hero" style="background:linear-gradient(135deg,#00b894,#00cec9,#0984e3);">
  <div style="font-size:64px;margin-bottom:10px;">🎉🏆✨</div>
  <h1 style="color:#fff;">¡CUENTA ACTIVADA!</h1>
</div>
<div class="body">
  <p>¡Hola <strong style="color:#00f5ff;">{nombre}</strong>! 🦁</p>
  <p>Tu cuenta está <strong style="color:#39ff14;">ACTIVA</strong>. ¡Ya puedes comenzar la aventura!</p>
  <div class="box box-gold" style="text-align:center;">
    <div class="label">🔑 Tu Código de Licencia</div>
    <div class="code">{licencia}</div>
    <p style="margin:8px 0 0;color:#FFD700;">Válida hasta: <strong>{fecha_vence}</strong></p>
  </div>
  {extra}
  <div class="box box-cyan">
    <div class="label">🚀 Cómo ingresar</div>
    <ol>
      <li>Abre el juego en tu navegador</li>
      <li>Escribe tu código de licencia en "🎮 JUGAR"</li>
      <li>¡Elige tu avatar y comienza la aventura!</li>
    </ol>
  </div>
</div>""")

def email_recuperacion(nombre: str, licencia: str) -> str:
    return _base(f"""
<div class="hero" style="background:linear-gradient(135deg,#6c5ce7,#a29bfe,#74b9ff);">
  <div style="font-size:64px;margin-bottom:10px;">🔑💌✨</div>
  <h1 style="color:#fff;">RECUPERACIÓN DE LICENCIA</h1>
</div>
<div class="body">
  <p>¡Hola <strong style="color:#00f5ff;">{nombre}</strong>! 👋</p>
  <p>Aquí está tu código de acceso a <strong>Aventura de Tablas Pro</strong>.</p>
  <div class="box box-purple" style="text-align:center;">
    <div class="label">🔑 Tu Código</div>
    <div class="code">{licencia}</div>
  </div>
  <div class="box box-cyan">
    <div class="label">🚀 Cómo usarlo</div>
    <ol>
      <li>Abre el juego en tu navegador</li>
      <li>Escribe el código en la pantalla de inicio</li>
      <li>¡Continúa tu aventura!</li>
    </ol>
  </div>
  <p style="font-size:12px;color:#5060a0;text-align:center;">Si tú no solicitaste esto, ignora este correo.</p>
</div>""")

def email_progreso(nombre: str, correo: str, mundos: int, fallos_json: str,
                   es_final: bool = False, maestro_nombre: str = "") -> bool:
    try:
        fallos: dict = json.loads(fallos_json or "{}")
    except:
        fallos = {}

    tablas_malas = sorted(fallos.items(), key=lambda x: -int(x[1] or 0))
    tablas_dificiles = [(t, c) for t, c in tablas_malas if int(c) >= 3]

    tablas_html = ""
    if tablas_dificiles:
        filas = "".join(
            f"<tr><td style='padding:8px 12px;border-bottom:1px solid rgba(255,255,255,0.08);color:#b0b8ff;'>"
            f"Tabla del {t}</td>"
            f"<td style='padding:8px 12px;border-bottom:1px solid rgba(255,255,255,0.08);color:#ff006e;font-weight:700;'>"
            f"{c} errores</td></tr>"
            for t, c in tablas_dificiles
        )
        tablas_html = f"""
  <div class="box box-pink">
    <div class="label">⚠️ Tablas que necesitan más práctica</div>
    <table style="width:100%;border-collapse:collapse;">{filas}</table>
    <p style="font-size:13px;color:#b0b8ff;margin-top:12px;">💡 Recomendamos practicar estas tablas en casa con ejercicios adicionales.</p>
  </div>"""
    else:
        tablas_html = """<div class="box box-green">
    <div class="label">✅ Sin tablas problemáticas</div>
    <p style="margin:0;color:#b0b8ff;">¡Excelente rendimiento! El alumno domina todas las tablas practicadas.</p>
  </div>"""

    pct = round((mundos / 10) * 100)
    titulo = "🏆 ¡REPORTE FINAL!" if es_final else f"📊 REPORTE DE AVANCE — {mundos} Mundos"
    maestro_txt = f"<p>Copia enviada al maestro <strong style='color:#a29bfe;'>{maestro_nombre}</strong>.</p>" if maestro_nombre else ""

    html = _base(f"""
<div class="hero" style="background:linear-gradient(135deg,#0984e3,#00b894,#6c5ce7);">
  <div style="font-size:64px;margin-bottom:10px;">{"🏆👑✨" if es_final else "📊⭐🎮"}</div>
  <h1 style="color:#fff;">{titulo}</h1>
</div>
<div class="body">
  <p>¡Hola! Aquí está el {"reporte final" if es_final else "reporte de avance"} de <strong style="color:#00f5ff;">{nombre}</strong>.</p>
  {maestro_txt}
  <div class="box box-gold">
    <div class="label">🌍 Progreso</div>
    <p style="margin:0;font-size:22px;font-weight:700;color:#FFD700;">{mundos} / 10 mundos completados ({pct}%)</p>
    <div class="bar-bg"><div class="bar" style="width:{pct}%;"></div></div>
  </div>
  {tablas_html}
  {"<div class='box box-green'><div class='label'>🎉 Logro final</div><p style='margin:0;font-size:16px;color:#39ff14;font-weight:700;'>¡Aventurero completó todos los mundos! Domina las tablas del 1 al 10. 🦁⚔️</p></div>" if es_final else ""}
</div>""")
    return enviar_correo(correo, f"{'🏆 Reporte Final' if es_final else f'📊 Reporte de Avance ({mundos} mundos)'} — {nombre}", html)

# ─── HELPERS ──────────────────────────────────────────────────
def _generar_codigo(nombre: str, tipo: str) -> str:
    prefijo = "MAE" if tipo == "maestro" else "ADM" if tipo == "admin" else "ALU"
    partes = re.sub(r"[^a-zA-ZáéíóúÁÉÍÓÚñÑ]", " ", nombre).split()
    slug = partes[0][:5].upper() if partes else "USR"
    # Quitar acentos básicos
    for a, b in [("Á","A"),("É","E"),("Í","I"),("Ó","O"),("Ú","U"),("Ñ","N"),
                  ("á","a"),("é","e"),("í","i"),("ó","o"),("ú","u"),("ñ","n")]:
        slug = slug.replace(a, b)
    anio = datetime.now().year
    rand = "".join(random.choices(string.digits, k=3))
    return f"{prefijo}-{slug}-{anio}-{rand}"

# ─── ENDPOINTS ────────────────────────────────────────────────

@app.get("/")
def root():
    return {"status": "ok", "app": "Aventura de Tablas Pro v3.0", "db": "SQLite local"}

@app.get("/api/test")
def test_conexion():
    """Endpoint para verificar que el backend está corriendo."""
    conn = get_db()
    try:
        total = conn.execute("SELECT COUNT(*) as n FROM Licencias").fetchone()["n"]
        admin = get_admin_licencia()
        return {"status": "ok", "total_licencias": total, "admin": admin[:3] + "***"}
    finally:
        conn.close()

# ── Validar licencia ──────────────────────────────────────────
@app.post("/api/validar-licencia")
def validar_licencia(data: ValidarLicencia):
    codigo = data.licencia.strip()

    # ── Bypass directo para el admin ──────────────────────────
    admin_actual = get_admin_licencia()
    if codigo == admin_actual:
        conn = get_db()
        try:
            # Asegurar que el admin exista en la tabla
            lic = conn.execute("SELECT * FROM Licencias WHERE Licencia=?", (codigo,)).fetchone()
            if not lic:
                conn.execute(
                    "INSERT OR IGNORE INTO Licencias (Licencia,Activa,Tipo,Nombre,Correo) VALUES (?,?,?,?,?)",
                    (codigo, "SI", "admin", "Admin", EMAIL_FROM)
                )
                conn.commit()
            return {
                "valido": True, "tipo": "admin",
                "nombre": (lic["Nombre"] if lic else None) or "Admin",
                "correo": (lic["Correo"] if lic else None) or EMAIL_FROM,
                "monedas": 0, "inventario": "", "nivel_max": 11,
                "fila": 0, "grado": "", "maestro_licencia": "", "maestro_nombre": "",
            }
        finally:
            conn.close()

    conn = get_db()
    try:
        lic = conn.execute(
            "SELECT * FROM Licencias WHERE Licencia=?", (codigo,)
        ).fetchone()
        if not lic:
            raise HTTPException(404, "Licencia no encontrada. Verifica que esté bien escrita.")
        if lic["Activa"] != "SI":
            raise HTTPException(403, "Licencia desactivada. Contacta al administrador.")

        maestro_nombre = ""
        try:
            if lic["Maestro_Licencia"]:
                mae = conn.execute(
                    "SELECT Nombre FROM Licencias WHERE Licencia=?", (lic["Maestro_Licencia"],)
                ).fetchone()
                if mae:
                    maestro_nombre = mae["Nombre"] or ""
        except Exception:
            pass

        def safe(row, key, default=""):
            try:
                return row[key] if row[key] is not None else default
            except Exception:
                return default

        return {
            "valido":          True,
            "tipo":            safe(lic, "Tipo", "alumno"),
            "nombre":          safe(lic, "Nombre"),
            "correo":          safe(lic, "Correo"),
            "monedas":         int(lic["Monedas"] or 0),
            "inventario":      safe(lic, "Inventario"),
            "nivel_max":       int(lic["Nivel_Max"] or 1),
            "fila":            lic["id"],
            "grado":           safe(lic, "Grado"),
            "maestro_licencia":safe(lic, "Maestro_Licencia"),
            "maestro_nombre":  maestro_nombre,
        }
    finally:
        conn.close()

# ── Registro público ──────────────────────────────────────────
@app.post("/api/registro")
async def registro(data: SolicitudRegistro, bg: BackgroundTasks):
    conn = get_db()
    try:
        conn.execute(
            "INSERT INTO Solicitudes (Fecha,Nombre,Correo,Celular,Escuela,Tipo,Grado,Num_Alumnos,Estado) "
            "VALUES (?,?,?,?,?,?,?,?,?)",
            (datetime.now().strftime("%Y-%m-%d %H:%M"), data.nombre, data.correo,
             data.celular, data.escuela, data.tipo or "alumno",
             data.grado or "", data.num_alumnos or 0, "Pendiente")
        )
        conn.commit()
        if data.correo and EMAIL_PASS:
            bg.add_task(
                enviar_correo, data.correo,
                "🎮 Aventura de Tablas — ¡Solicitud Recibida!",
                email_solicitud(data.nombre, data.tipo == "maestro")
            )
        return {"ok": True}
    except Exception as e:
        raise HTTPException(500, str(e))
    finally:
        conn.close()

# ── Actualizar progreso ───────────────────────────────────────
@app.post("/api/actualizar-progreso")
async def actualizar_progreso(data: ActualizarProgreso, bg: BackgroundTasks):
    conn = get_db()
    try:
        lic = conn.execute("SELECT * FROM Licencias WHERE Licencia=?", (data.licencia.strip(),)).fetchone()
        if not lic:
            raise HTTPException(404, "Licencia no encontrada")

        prev_mundos = int(lic["Mundos_Completados"] or 0)
        new_mundos  = data.mundos_completados if data.mundos_completados is not None else prev_mundos

        conn.execute("""
            UPDATE Licencias
            SET Monedas=?, Inventario=?, Nivel_Max=?,
                Nombre=CASE WHEN ? IS NOT NULL THEN ? ELSE Nombre END,
                Mundos_Completados=?,
                Fallos_Tablas=CASE WHEN ? IS NOT NULL THEN ? ELSE Fallos_Tablas END,
                Tiempo_Total_Min=Tiempo_Total_Min + ?
            WHERE Licencia=?
        """, (
            data.monedas, data.inventario, data.nivel_max,
            data.nombre, data.nombre,
            new_mundos,
            data.fallos_tablas, data.fallos_tablas,
            data.tiempo_min or 0,
            data.licencia.strip()
        ))
        conn.commit()

        # Email cada 3 mundos (cuando cruza múltiplo de 3)
        correo = lic["Correo"] or ""
        nombre = data.nombre or lic["Nombre"] or "Aventurero"
        fallos = data.fallos_tablas or lic["Fallos_Tablas"] or "{}"

        if (correo and EMAIL_PASS and new_mundos > prev_mundos and
                new_mundos > 0 and new_mundos % 3 == 0 and new_mundos < 10):
            # Buscar nombre del maestro
            maestro_nombre = ""
            if lic["Maestro_Licencia"]:
                mae = conn.execute("SELECT Nombre FROM Licencias WHERE Licencia=?",
                                   (lic["Maestro_Licencia"],)).fetchone()
                if mae:
                    maestro_nombre = mae["Nombre"] or ""
            bg.add_task(email_progreso, nombre, correo, new_mundos, fallos, False, maestro_nombre)

            # Enviar copia al maestro si existe
            if lic["Maestro_Licencia"]:
                mae_row = conn.execute("SELECT * FROM Licencias WHERE Licencia=?",
                                       (lic["Maestro_Licencia"],)).fetchone()
                if mae_row and mae_row["Correo"] and EMAIL_PASS:
                    bg.add_task(email_progreso, nombre, mae_row["Correo"], new_mundos, fallos, False, "")

        # Reporte final al completar todos los mundos
        if correo and EMAIL_PASS and new_mundos >= 10 and prev_mundos < 10:
            maestro_nombre = ""
            if lic["Maestro_Licencia"]:
                mae = conn.execute("SELECT Nombre FROM Licencias WHERE Licencia=?",
                                   (lic["Maestro_Licencia"],)).fetchone()
                if mae: maestro_nombre = mae["Nombre"] or ""
            bg.add_task(email_progreso, nombre, correo, 10, fallos, True, maestro_nombre)

        return {"ok": True}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, str(e))
    finally:
        conn.close()

# ── Sesión: iniciar ───────────────────────────────────────────
@app.post("/api/sesion/iniciar")
def sesion_iniciar(data: IniciarSesion):
    conn = get_db()
    try:
        now = datetime.now()
        conn.execute(
            "INSERT INTO Sesiones (Licencia,Inicio,Fecha) VALUES (?,?,?)",
            (data.licencia.strip(), now.isoformat(), now.strftime("%Y-%m-%d"))
        )
        conn.commit()
        return {"ok": True}
    except Exception as e:
        return {"ok": False, "error": str(e)}
    finally:
        conn.close()

# ── Sesión: terminar ──────────────────────────────────────────
@app.post("/api/sesion/terminar")
def sesion_terminar(data: TerminarSesion):
    conn = get_db()
    try:
        now = datetime.now()
        # Actualizar última sesión sin fin
        sesion = conn.execute(
            "SELECT id FROM Sesiones WHERE Licencia=? AND Fin='' ORDER BY id DESC LIMIT 1",
            (data.licencia.strip(),)
        ).fetchone()
        if sesion:
            conn.execute(
                "UPDATE Sesiones SET Fin=?, Tiempo_Min=? WHERE id=?",
                (now.isoformat(), data.tiempo_min or 0, sesion["id"])
            )
        # Acumular tiempo en Licencias
        conn.execute(
            "UPDATE Licencias SET Tiempo_Total_Min=Tiempo_Total_Min+? WHERE Licencia=?",
            (data.tiempo_min or 0, data.licencia.strip())
        )
        conn.commit()
        return {"ok": True}
    except Exception as e:
        return {"ok": False, "error": str(e)}
    finally:
        conn.close()

# ── Recuperar licencia ────────────────────────────────────────
@app.post("/api/recuperar-licencia")
async def recuperar_licencia(data: RecuperarLicencia, bg: BackgroundTasks):
    if not data.correo and not data.celular:
        raise HTTPException(400, "Proporciona tu correo o celular")
    conn = get_db()
    try:
        lic = None
        if data.correo and data.correo.strip():
            lic = conn.execute(
                "SELECT * FROM Licencias WHERE LOWER(Correo)=LOWER(?) AND Tipo!='admin'",
                (data.correo.strip(),)
            ).fetchone()
        if not lic and data.celular and data.celular.strip():
            lic = conn.execute(
                "SELECT * FROM Licencias WHERE Celular=? AND Tipo!='admin'",
                (data.celular.strip(),)
            ).fetchone()
        if not lic:
            raise HTTPException(404, "No encontramos una cuenta con esos datos.")
        correo_dest = lic["Correo"] or ""
        if not correo_dest:
            raise HTTPException(400, "Esta cuenta no tiene correo registrado. Contacta al administrador.")
        if EMAIL_PASS:
            bg.add_task(
                enviar_correo, correo_dest,
                "🔑 Aventura de Tablas — Tu código de licencia",
                email_recuperacion(lic["Nombre"] or "Aventurero", lic["Licencia"])
            )
        at = correo_dest.find("@")
        correo_masked = correo_dest[:2] + "***" + correo_dest[at:]
        return {"ok": True, "correo": correo_masked}
    finally:
        conn.close()

# ── Admin — cambiar licencia/contraseña ──────────────────────
@app.post("/api/admin/cambiar-licencia")
def cambiar_licencia_admin(data: CambiarAdminLicencia):
    admin_actual = get_admin_licencia()
    if data.licencia_actual.strip() != admin_actual:
        raise HTTPException(403, "La licencia actual no es correcta")
    nueva = data.licencia_nueva.strip()
    if len(nueva) < 6:
        raise HTTPException(400, "La nueva licencia debe tener al menos 6 caracteres")
    conn = get_db()
    try:
        conn.execute("UPDATE config SET value=? WHERE key='admin_licencia'", (nueva,))
        conn.execute("UPDATE Licencias SET Licencia=? WHERE Licencia=?", (nueva, admin_actual))
        conn.commit()
        return {"ok": True}
    except sqlite3.IntegrityError:
        raise HTTPException(409, "Ese código ya está en uso")
    except Exception as e:
        raise HTTPException(500, str(e))
    finally:
        conn.close()

# ── Admin — listar licencias ──────────────────────────────────
@app.get("/api/admin/licencias")
def listar_licencias():
    conn = get_db()
    try:
        rows = conn.execute("SELECT * FROM Licencias ORDER BY id DESC").fetchall()
        return {"licencias": [dict(r) for r in rows]}
    finally:
        conn.close()

# ── Admin — reportes de alumnos ───────────────────────────────
@app.get("/api/admin/reportes")
def admin_reportes():
    conn = get_db()
    try:
        rows = conn.execute("""
            SELECT l.*, m.Nombre as Maestro_Nombre
            FROM Licencias l
            LEFT JOIN Licencias m ON l.Maestro_Licencia = m.Licencia
            WHERE l.Tipo = 'alumno'
            ORDER BY l.Mundos_Completados DESC, l.Tiempo_Total_Min DESC
        """).fetchall()
        return {"reportes": [dict(r) for r in rows]}
    finally:
        conn.close()

# ── Admin — generar código automático ────────────────────────
@app.post("/api/admin/generar-codigo")
def generar_codigo(data: GenerarCodigo):
    conn = get_db()
    try:
        for _ in range(10):
            codigo = _generar_codigo(data.nombre, data.tipo)
            existe = conn.execute("SELECT id FROM Licencias WHERE Licencia=?", (codigo,)).fetchone()
            if not existe:
                return {"codigo": codigo}
        raise HTTPException(500, "No se pudo generar un código único")
    finally:
        conn.close()

# ── Admin — crear licencia ────────────────────────────────────
@app.post("/api/admin/crear-licencia")
def crear_licencia(data: CrearLicencia):
    conn = get_db()
    try:
        conn.execute("""
            INSERT INTO Licencias
            (Licencia,Activa,Tipo,Nombre,Correo,Celular,Grado,Maestro_Licencia)
            VALUES (?,?,?,?,?,?,?,?)
        """, (data.codigo.strip(), "NO", data.tipo,
              data.nombre or "", data.correo or "", data.celular or "",
              data.grado or "", data.maestro_licencia or ""))
        conn.commit()
        return {"ok": True}
    except sqlite3.IntegrityError:
        raise HTTPException(409, f"Ya existe la licencia '{data.codigo}'.")
    except Exception as e:
        raise HTTPException(500, str(e))
    finally:
        conn.close()

# ── Admin — editar licencia ───────────────────────────────────
@app.post("/api/admin/editar-licencia")
def editar_licencia(data: EditarLicencia):
    conn = get_db()
    try:
        conn.execute("""
            UPDATE Licencias
            SET Nombre=?, Correo=?, Celular=?, Monedas=?, Nivel_Max=?,
                Grado=?, Maestro_Licencia=?
            WHERE Licencia=?
        """, (data.nombre or "", data.correo or "", data.celular or "",
              data.monedas or 0, data.nivel_max or 1,
              data.grado or "", data.maestro_licencia or "",
              data.licencia.strip()))
        conn.commit()
        return {"ok": True}
    except Exception as e:
        raise HTTPException(500, str(e))
    finally:
        conn.close()

# ── Admin — activar licencia ──────────────────────────────────
@app.post("/api/admin/activar-licencia")
async def activar_licencia(data: AccionLicencia, bg: BackgroundTasks):
    conn = get_db()
    try:
        lic = conn.execute("SELECT * FROM Licencias WHERE Licencia=?", (data.codigo.strip(),)).fetchone()
        if not lic:
            raise HTTPException(404, "Licencia no encontrada")
        fecha_vence = (datetime.now() + timedelta(days=365)).strftime("%d/%m/%Y")
        conn.execute(
            "UPDATE Licencias SET Activa='SI', Fecha_Vence=? WHERE Licencia=?",
            (fecha_vence, data.codigo.strip())
        )
        conn.commit()
        correo = lic["Correo"] or ""
        nombre = lic["Nombre"] or "Aventurero"
        enviado = False

        if correo and EMAIL_PASS:
            # Buscar maestro si tiene
            maestro_nombre, grado_maestro = "", ""
            if lic["Maestro_Licencia"]:
                mae = conn.execute(
                    "SELECT Nombre, Grado FROM Licencias WHERE Licencia=?",
                    (lic["Maestro_Licencia"],)
                ).fetchone()
                if mae:
                    maestro_nombre = mae["Nombre"] or ""
                    grado_maestro  = mae["Grado"] or lic["Grado"] or ""

            bg.add_task(
                enviar_correo, correo,
                "✅ Aventura de Tablas — ¡Tu cuenta está activa!",
                email_activacion(nombre, data.codigo, fecha_vence, maestro_nombre, grado_maestro)
            )
            enviado = True

        return {"ok": True, "correo_enviado": enviado}
    finally:
        conn.close()

# ── Admin — desactivar licencia ───────────────────────────────
@app.post("/api/admin/desactivar-licencia")
def desactivar_licencia(data: AccionLicencia):
    conn = get_db()
    try:
        conn.execute("UPDATE Licencias SET Activa='NO' WHERE Licencia=?", (data.codigo.strip(),))
        conn.commit()
        return {"ok": True}
    finally:
        conn.close()

# ── Admin — eliminar licencia ─────────────────────────────────
@app.delete("/api/admin/eliminar-licencia/{codigo}")
def eliminar_licencia(codigo: str):
    conn = get_db()
    try:
        r = conn.execute("DELETE FROM Licencias WHERE Licencia=?", (codigo,))
        conn.commit()
        if r.rowcount == 0:
            raise HTTPException(404, "Licencia no encontrada")
        return {"ok": True}
    finally:
        conn.close()

# ── Admin — solicitudes ───────────────────────────────────────
@app.get("/api/admin/solicitudes")
def listar_solicitudes():
    conn = get_db()
    try:
        rows = conn.execute("SELECT * FROM Solicitudes ORDER BY id DESC").fetchall()
        return {"solicitudes": [dict(r) for r in rows]}
    finally:
        conn.close()

# ── Reporte individual por licencia ──────────────────────────
@app.get("/api/reporte/{licencia}")
def reporte_alumno(licencia: str):
    conn = get_db()
    try:
        lic = conn.execute("""
            SELECT l.*, m.Nombre as Maestro_Nombre
            FROM Licencias l
            LEFT JOIN Licencias m ON l.Maestro_Licencia = m.Licencia
            WHERE l.Licencia=?
        """, (licencia,)).fetchone()
        if not lic:
            raise HTTPException(404, "Licencia no encontrada")
        sesiones = conn.execute(
            "SELECT * FROM Sesiones WHERE Licencia=? ORDER BY id DESC LIMIT 20",
            (licencia,)
        ).fetchall()
        return {
            "alumno": dict(lic),
            "sesiones": [dict(s) for s in sesiones],
        }
    finally:
        conn.close()

# ── Maestro — ver sus alumnos ─────────────────────────────────
@app.get("/api/maestro/alumnos/{licencia}")
def maestro_alumnos(licencia: str):
    conn = get_db()
    try:
        mae = conn.execute("SELECT * FROM Licencias WHERE Licencia=? AND Tipo='maestro'", (licencia,)).fetchone()
        if not mae:
            raise HTTPException(403, "Licencia de maestro no válida")
        alumnos = conn.execute(
            "SELECT * FROM Licencias WHERE Maestro_Licencia=? AND Tipo='alumno' ORDER BY Nombre",
            (licencia,)
        ).fetchall()
        return {"alumnos": [dict(a) for a in alumnos], "maestro": dict(mae)}
    finally:
        conn.close()
