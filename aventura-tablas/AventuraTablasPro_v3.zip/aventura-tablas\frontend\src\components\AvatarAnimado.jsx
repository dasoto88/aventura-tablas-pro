import React, { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { TIENDA_ITEMS, AVATARES } from "../utils/gameData";

// Obstáculos por mundo — desaparecen al responder correcto
const OBSTACULOS_MUNDO = [
  ["🌿","🍄","🐛","🌵","🕷️","🌿","🍄","🐛","🌵","🕷️"],  // 0 Bosque
  ["🦈","🐙","🌊","🐚","🦑","🦈","🐙","🌊","🐚","🦑"],   // 1 Océano
  ["🔥","🌋","💎","🪨","🔥","🌋","💎","🪨","🔥","🌋"],   // 2 Volcán
  ["⛄","🌨️","🏔️","❄️","🐧","⛄","🌨️","🏔️","❄️","🐧"],  // 3 Hielo
  ["👻","🕯️","🦇","💀","🕸️","👻","🕯️","🦇","💀","🕸️"],  // 4 Fantasmas
  ["☁️","🌩️","⚡","🌪️","☁️","🌩️","⚡","🌪️","☁️","🌩️"], // 5 Cielo
  ["🤖","⚙️","💾","🔧","🔌","🤖","⚙️","💾","🔧","🔌"],   // 6 Cyber
  ["🌙","⭐","🪐","🚀","🛸","🌙","⭐","🪐","🚀","🛸"],    // 7 Espacio
  ["🐲","🏰","⚔️","🛡️","💎","🐲","🏰","⚔️","🛡️","💎"],  // 8 Dragones
  ["🌊","⚓","🏴‍☠️","💰","🦜","🌊","⚓","🏴‍☠️","💰","🦜"],// 9 Piratas
  ["👑","🌟","💫","✨","🔮","👑","🌟","💫","✨","🔮"],    // 10 Supremo
];

const CASILLA_POSITIONS = Array.from({ length: 10 }, (_, i) => i);

// Inyectar CSS de animación de caminar una sola vez
if (typeof document !== "undefined" && !document.getElementById("avatar-walk-css")) {
  const style = document.createElement("style");
  style.id = "avatar-walk-css";
  style.textContent = `
    @keyframes avatar-walk {
      0%   { transform: translateY(0px) rotate(-4deg) scaleX(1); }
      25%  { transform: translateY(-8px) rotate(0deg) scaleX(1.05); }
      50%  { transform: translateY(0px) rotate(4deg) scaleX(1); }
      75%  { transform: translateY(-5px) rotate(0deg) scaleX(1.05); }
      100% { transform: translateY(0px) rotate(-4deg) scaleX(1); }
    }
    @keyframes avatar-idle {
      0%   { transform: translateY(0px) scale(1); }
      50%  { transform: translateY(-5px) scale(1.03); }
      100% { transform: translateY(0px) scale(1); }
    }
    @keyframes avatar-attack {
      0%   { transform: translateX(0) scaleX(1) rotate(0); }
      30%  { transform: translateX(18px) scaleX(1.1) rotate(-5deg); }
      60%  { transform: translateX(8px) scaleX(1.05) rotate(5deg); }
      100% { transform: translateX(0) scaleX(1) rotate(0); }
    }
    @keyframes avatar-hurt {
      0%   { transform: translateX(0) rotate(0); filter: brightness(1); }
      20%  { transform: translateX(-12px) rotate(-8deg); filter: brightness(2) hue-rotate(0deg); }
      40%  { transform: translateX(8px) rotate(5deg); filter: brightness(0.5) hue-rotate(200deg); }
      60%  { transform: translateX(-6px) rotate(-4deg); filter: brightness(1.5); }
      100% { transform: translateX(0) rotate(0); filter: brightness(1); }
    }
    @keyframes avatar-celebrate {
      0%   { transform: scale(1) rotate(0); }
      25%  { transform: scale(1.2) rotate(-10deg); }
      50%  { transform: scale(1.1) rotate(10deg); }
      75%  { transform: scale(1.2) rotate(-5deg); }
      100% { transform: scale(1) rotate(0); }
    }
    @keyframes obstaculo-pop {
      0%   { transform: scale(1); opacity: 1; }
      50%  { transform: scale(1.4); opacity: 0.8; }
      100% { transform: scale(0); opacity: 0; }
    }
    @keyframes explosion-flash {
      0%   { transform: scale(0.5); opacity: 1; }
      60%  { transform: scale(1.8); opacity: 1; }
      100% { transform: scale(2.5); opacity: 0; }
    }
  `;
  document.head.appendChild(style);
}

// Mapa de animación CSS según estado
const CSS_ANIM = {
  idle:      "avatar-idle 2s ease-in-out infinite",
  win:       "avatar-celebrate 0.6s ease-in-out 3",
  sad:       "avatar-hurt 0.5s ease-in-out",
  attack:    "avatar-attack 0.4s ease-out",
  retrocede: "avatar-hurt 0.6s ease-in-out",
  celebrate: "avatar-celebrate 1s ease-in-out infinite",
  walk:      "avatar-walk 0.4s ease-in-out infinite",
};

export default function AvatarAnimado({
  avatarId,
  animacion = "idle",
  aciertos = 0,
  inventario = [],
  equipado = {},
  size = 80,
}) {
  const avatar = AVATARES.find(a => a.id === avatarId) || AVATARES[0];
  const [mensajeFlotante, setMensajeFlotante] = useState(null);
  const [particulas, setParticulas] = useState([]);
  const prevAciertos = useRef(aciertos);

  const itemCabeza    = equipado.cabeza    ? TIENDA_ITEMS.find(i => i.id === equipado.cabeza)    : null;
  const itemArma      = equipado.arma      ? TIENDA_ITEMS.find(i => i.id === equipado.arma)      : null;
  const itemAccesorio = equipado.accesorio ? TIENDA_ITEMS.find(i => i.id === equipado.accesorio) : null;

  useEffect(() => {
    if (aciertos > prevAciertos.current) {
      const msgs = ["¡Sigue así! 🔥", "¡Avanzas! ⬆️", "¡Correcto! ⚡", "¡Genial! ⭐", "¡Eso es! 🎯"];
      setMensajeFlotante(msgs[Math.floor(Math.random() * msgs.length)]);
      setParticulas(Array.from({ length: 8 }, (_, i) => ({
        id: Date.now() + i,
        x: (Math.random() - 0.5) * 100,
        y: -(30 + Math.random() * 50),
        color: ["#FFD700","#00f5ff","#ff006e","#39ff14","#ff9f00"][i % 5],
      })));
      setTimeout(() => { setMensajeFlotante(null); setParticulas([]); }, 1400);
    } else if (aciertos < prevAciertos.current) {
      setMensajeFlotante("¡Cuidado! 😰");
      setTimeout(() => setMensajeFlotante(null), 1000);
    }
    prevAciertos.current = aciertos;
  }, [aciertos]);

  const cssAnim = CSS_ANIM[animacion] || CSS_ANIM.idle;

  return (
    <div style={{ position: "relative", display: "inline-block", width: size + 70, textAlign: "center" }}>

      {/* Mensaje flotante */}
      <AnimatePresence>
        {mensajeFlotante && (
          <motion.div
            initial={{ opacity: 0, y: 0, scale: 0.6 }}
            animate={{ opacity: 1, y: -48, scale: 1 }}
            exit={{ opacity: 0, y: -80 }}
            transition={{ duration: 0.4 }}
            style={{
              position: "absolute", top: -10, left: "50%", transform: "translateX(-50%)",
              background: "rgba(0,0,0,0.8)", backdropFilter: "blur(8px)",
              border: "1px solid rgba(255,255,255,0.25)",
              borderRadius: 20, padding: "5px 14px", whiteSpace: "nowrap",
              fontFamily: "Nunito, sans-serif", fontSize: 14, fontWeight: 800,
              color: "#fff", zIndex: 20, pointerEvents: "none",
              boxShadow: "0 4px 20px rgba(0,245,255,0.3)",
            }}
          >
            {mensajeFlotante}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Partículas de acierto */}
      {particulas.map(p => (
        <motion.div
          key={p.id}
          initial={{ opacity: 1, x: 0, y: 0, scale: 1 }}
          animate={{ opacity: 0, x: p.x, y: p.y, scale: 0.2 }}
          transition={{ duration: 1, ease: "easeOut" }}
          style={{
            position: "absolute", top: "30%", left: "50%",
            width: 10, height: 10, borderRadius: "50%",
            background: p.color,
            boxShadow: `0 0 6px ${p.color}`,
            pointerEvents: "none", zIndex: 15,
          }}
        />
      ))}

      {/* Item en la cabeza */}
      {itemCabeza && (
        <motion.div
          animate={{ y: [0, -3, 0] }}
          transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
          style={{
            position: "absolute", top: -size * 0.38, left: "50%",
            transform: "translateX(-50%)",
            fontSize: size * 0.42, lineHeight: 1, zIndex: 10,
            filter: "drop-shadow(0 3px 6px rgba(0,0,0,0.6))",
          }}
        >
          {itemCabeza.emoji}
        </motion.div>
      )}

      {/* Cuerpo principal — animación CSS tipo videojuego */}
      <div
        style={{
          fontSize: size,
          lineHeight: 1,
          display: "inline-block",
          filter: `drop-shadow(0 0 ${size * 0.22}px ${avatar.color})`,
          cursor: "default",
          userSelect: "none",
          animation: cssAnim,
          transformOrigin: "bottom center",
          willChange: "transform",
        }}
      >
        {avatar.emoji}
      </div>

      {/* Arma a la derecha */}
      {itemArma && (
        <motion.div
          animate={animacion === "attack"
            ? { rotate: [-30, 45], x: [0, 20], scale: [1, 1.2] }
            : { rotate: [0, 8, 0] }
          }
          transition={animacion === "attack"
            ? { duration: 0.35 }
            : { duration: 2, repeat: Infinity, ease: "easeInOut" }
          }
          style={{
            position: "absolute", top: "38%", right: -size * 0.38,
            fontSize: size * 0.48, lineHeight: 1, zIndex: 10,
            filter: "drop-shadow(0 0 8px rgba(255,214,0,0.7))",
          }}
        >
          {itemArma.emoji}
        </motion.div>
      )}

      {/* Accesorio abajo-izquierda */}
      {itemAccesorio && (
        <motion.div
          animate={{ scale: [1, 1.06, 1] }}
          transition={{ duration: 1.5, repeat: Infinity }}
          style={{
            position: "absolute", bottom: 0, left: -size * 0.28,
            fontSize: size * 0.4, lineHeight: 1, zIndex: 10,
          }}
        >
          {itemAccesorio.emoji}
        </motion.div>
      )}

      {/* Sombra */}
      <motion.div
        animate={animacion === "sad" || animacion === "retrocede"
          ? { scaleX: 0.55, opacity: 0.25 }
          : { scaleX: 1, opacity: 0.4 }
        }
        transition={{ duration: 0.35 }}
        style={{
          width: size * 0.7, height: 8,
          background: "radial-gradient(ellipse, rgba(0,0,0,0.55) 0%, transparent 70%)",
          margin: "4px auto 0", borderRadius: "50%",
        }}
      />
    </div>
  );
}

// ─── CAMINO CON OBSTÁCULOS — ESTILO VIDEOJUEGO ───────────────
export function CaminoAvatar({ avatarId, aciertos, inventario, equipado, mundoId = 0 }) {
  const avatar = AVATARES.find(a => a.id === avatarId) || AVATARES[0];
  const obstaculos = OBSTACULOS_MUNDO[Math.min(mundoId, OBSTACULOS_MUNDO.length - 1)];

  // Accesorios equipados para mostrar en el mini avatar del camino
  const itemCabeza    = equipado?.cabeza    ? TIENDA_ITEMS.find(i => i.id === equipado.cabeza)    : null;
  const itemArma      = equipado?.arma      ? TIENDA_ITEMS.find(i => i.id === equipado.arma)      : null;

  const prevAciertos = useRef(aciertos);
  const [recienCompletado, setRecienCompletado] = useState(-1);
  const [posAvatar, setPosAvatar] = useState(aciertos);

  useEffect(() => {
    if (aciertos > prevAciertos.current) {
      const sq = aciertos - 1;
      setRecienCompletado(sq);
      setTimeout(() => setRecienCompletado(-1), 700);
      setPosAvatar(aciertos - 0.5);
      setTimeout(() => setPosAvatar(aciertos), 350);
    }
    prevAciertos.current = aciertos;
  }, [aciertos]);

  // Casillas más pequeñas para caber sin hacer scroll
  const CASILLA_W = 28;
  const CASILLA_H = 16;
  const AVATAR_FONT = 20;
  const AVATAR_TOP = -26;
  const OBST_FONT = 14;
  const OBST_H = 22;

  return (
    <div style={{ padding: "4px 4px 0" }}>
      {/* Pista de casillas */}
      <div style={{
        display: "flex", gap: 2, justifyContent: "center",
        alignItems: "flex-end", position: "relative",
      }}>
        {CASILLA_POSITIONS.map(i => {
          const completa = i < aciertos;
          const esActual = i === Math.floor(posAvatar);
          const obstaculoEmoji = obstaculos[i] || "❓";
          const fueRecienLimpiada = recienCompletado === i;

          return (
            <div key={i} style={{ position: "relative", width: CASILLA_W, height: CASILLA_W + OBST_H + 4, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "flex-end" }}>

              {/* Obstáculo / explosión / limpio */}
              <div style={{ position: "absolute", top: 0, left: "50%", transform: "translateX(-50%)", fontSize: OBST_FONT, height: OBST_H, display: "flex", alignItems: "center", justifyContent: "center" }}>
                {fueRecienLimpiada ? (
                  <span style={{ animation: "explosion-flash 0.6s ease-out forwards", display: "inline-block" }}>💥</span>
                ) : completa ? (
                  <motion.span initial={{ scale: 0, rotate: -30 }} animate={{ scale: 1, rotate: 0 }} transition={{ type: "spring", stiffness: 300 }} style={{ display: "inline-block", fontSize: 12 }}>
                    ✅
                  </motion.span>
                ) : !esActual ? (
                  <motion.span
                    animate={{ y: [0, -2, 0] }}
                    transition={{ duration: 1.2 + i * 0.1, repeat: Infinity, ease: "easeInOut" }}
                    style={{ display: "inline-block", opacity: 0.85 }}
                  >
                    {obstaculoEmoji}
                  </motion.span>
                ) : null}
              </div>

              {/* Avatar encima de la casilla actual con accesorios */}
              {esActual && (
                <div style={{ position: "absolute", top: AVATAR_TOP, left: "50%", transform: "translateX(-50%)", zIndex: 10 }}>
                  {/* Sombrero mini */}
                  {itemCabeza && (
                    <div style={{ textAlign: "center", fontSize: 10, lineHeight: 1, marginBottom: 1, filter: "drop-shadow(0 1px 2px rgba(0,0,0,0.8))" }}>
                      {itemCabeza.emoji}
                    </div>
                  )}
                  <div style={{ display: "flex", alignItems: "center", gap: 1 }}>
                    <motion.div
                      initial={{ y: -4, x: -4 }}
                      animate={{ y: [-4, -10, -4], x: 0 }}
                      transition={{ duration: 0.7, ease: "easeInOut" }}
                      style={{
                        fontSize: AVATAR_FONT, lineHeight: 1,
                        filter: `drop-shadow(0 0 6px ${avatar.color})`,
                        animation: "avatar-walk 0.5s ease-in-out infinite",
                        transformOrigin: "bottom center",
                      }}
                    >
                      {avatar.emoji}
                    </motion.div>
                    {/* Arma mini */}
                    {itemArma && (
                      <div style={{ fontSize: 10, lineHeight: 1, filter: "drop-shadow(0 0 4px rgba(255,214,0,0.8))" }}>
                        {itemArma.emoji}
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Casilla de suelo */}
              <motion.div
                animate={esActual
                  ? { boxShadow: [`0 0 6px ${avatar.color}`, `0 0 16px ${avatar.color}`, `0 0 6px ${avatar.color}`] }
                  : {}
                }
                transition={{ duration: 1, repeat: Infinity }}
                style={{
                  width: CASILLA_W, height: CASILLA_H,
                  borderRadius: "5px 5px 3px 3px",
                  background: completa
                    ? "linear-gradient(180deg, #00b894 0%, #00836e 100%)"
                    : esActual
                    ? `linear-gradient(180deg, ${avatar.color}55 0%, ${avatar.color}22 100%)`
                    : "linear-gradient(180deg, rgba(80,80,120,0.5) 0%, rgba(40,40,80,0.7) 100%)",
                  border: `2px solid ${completa ? "#39ff14" : esActual ? avatar.color : "rgba(255,255,255,0.12)"}`,
                  transition: "background 0.4s, border-color 0.4s",
                }}
              />
            </div>
          );
        })}
      </div>

      {/* Texto de progreso */}
      <div style={{
        textAlign: "center", fontFamily: "Nunito, sans-serif",
        fontSize: 11, marginTop: 8,
        color: aciertos >= 10 ? "#FFD700" : "rgba(255,255,255,0.45)",
        fontWeight: aciertos >= 10 ? 800 : 400,
      }}>
        {aciertos === 0 && "¡Derrota los obstáculos respondiendo correctamente! ➡️"}
        {aciertos > 0 && aciertos < 10 && `¡Vas muy bien! Derrota ${10 - aciertos} más 💪`}
        {aciertos >= 10 && "⚔️ ¡¡EL BOSS TE ESPERA!! ¡PREPÁRATE! ⚔️"}
      </div>
    </div>
  );
}
